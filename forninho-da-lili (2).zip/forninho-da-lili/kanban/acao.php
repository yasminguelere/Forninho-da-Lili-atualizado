<?php
declare(strict_types=1);

/* Recebe os POSTs do quadro: adicionar, editar, mover de coluna e excluir pedidos. */

require __DIR__ . '/../nucleo/layout.php';
cabecalhos(true);
exigir_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('painel.php');
}
if (!csrf_valido()) {
    flash_set('erro', 'A página expirou. Tente de novo.');
    redirecionar('painel.php');
}

$acao = (string) ($_POST['acao'] ?? '');
$id   = (string) ($_POST['id'] ?? '');

switch ($acao) {
    case 'adicionar':
        [$dados, $erros, $antigos] = validar_pedido($_POST);
        if ($erros) {
            $_SESSION['flash_form'] = ['old' => $antigos, 'erros' => $erros];
            redirecionar('painel.php#novo-pedido');
        }
        atualizar_dados('pedidos', function (array &$lista) use ($dados): void {
            $lista[] = $dados + [
                'id' => novo_id(), 'status' => 'pendente',
                'criado_em' => date('c'), 'concluido_em' => null,
            ];
        });
        flash_set('ok', 'Pedido adicionado em Pendente.');
        redirecionar('painel.php');

    case 'editar':
        [$dados, $erros, $antigos] = validar_pedido($_POST);
        if ($erros) {
            $_SESSION['flash_form'] = ['old' => $antigos, 'erros' => $erros, 'id' => $id];
            redirecionar('editar.php?id=' . rawurlencode($id));
        }
        $achou = atualizar_dados('pedidos', function (array &$lista) use ($id, $dados): bool {
            foreach ($lista as &$p) {
                if (($p['id'] ?? '') === $id) {
                    $p = $dados + $p;   // mantém status, datas e id
                    return true;
                }
            }
            return false;
        });
        flash_set($achou ? 'ok' : 'erro', $achou ? 'Pedido atualizado.' : 'Pedido não encontrado.');
        redirecionar('painel.php');

    case 'mover':
        $destino = (string) ($_POST['destino'] ?? '');
        if (!isset(COLUNAS[$destino])) {
            flash_set('erro', 'Coluna inválida.');
            redirecionar('painel.php');
        }
        atualizar_dados('pedidos', function (array &$lista) use ($id, $destino): void {
            foreach ($lista as &$p) {
                if (($p['id'] ?? '') === $id) {
                    $p['status'] = $destino;
                    $p['concluido_em'] = $destino === 'entregue' ? date('c') : null;
                }
            }
        });
        flash_set('ok', 'Pedido movido para ' . COLUNAS[$destino] . '.');
        redirecionar('painel.php');

    case 'pagamento':
        $novo = (string) ($_POST['valor'] ?? '');
        if (!isset(PAGAMENTOS[$novo])) {
            redirecionar('painel.php');
        }
        atualizar_dados('pedidos', function (array &$lista) use ($id, $novo): void {
            foreach ($lista as &$p) {
                if (($p['id'] ?? '') === $id) {
                    $p['pagamento'] = $novo;
                }
            }
        });
        flash_set('ok', 'Pagamento marcado como ' . mb_strtolower(PAGAMENTOS[$novo]) . '.');
        redirecionar('painel.php');

    case 'excluir':
        atualizar_dados('pedidos', function (array &$lista) use ($id): void {
            $lista = array_values(array_filter($lista, fn ($p) => ($p['id'] ?? '') !== $id));
        });
        flash_set('ok', 'Pedido excluído.');
        redirecionar('painel.php');

    default:
        redirecionar('painel.php');
}
