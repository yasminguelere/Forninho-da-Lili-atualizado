<?php
declare(strict_types=1);

require __DIR__ . '/../nucleo/funcoes.php';
cabecalhos(true);
iniciar_sessao();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valido()) {
    sair_sessao();
}
redirecionar(URL_PUBLICO . 'index.php', 302);
