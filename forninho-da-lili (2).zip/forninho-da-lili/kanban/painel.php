<?php
declare(strict_types=1);

require __DIR__ . '/../nucleo/layout.php';
cabecalhos(true);
exigir_login();   // barreira de proteção: sem sessão ativa, volta para o login

$todos = array_map('normalizar_pedido', ler_dados('pedidos'));
$hoje  = date('Y-m-d');
$rank  = ['vermelho' => 0, 'amarelo' => 1, 'verde' => 2];

// MÉTRICAS FINANCEIRAS PRIVADAS: sempre sobre todos os pedidos da coluna Entregue, nunca filtradas
// e calculadas só aqui (o site público nunca lê os pedidos)
$entregues     = array_filter($todos, fn ($p) => $p['status'] === 'entregue');
$qtdEntregues  = count($entregues);
$faturamento   = array_sum(array_map(fn ($p) => (int) $p['valor_centavos'], $entregues));

// Filtros rápidos (GET)
$q    = mb_strtolower(limpar_texto($_GET['q'] ?? ''));
$fpag = isset(PAGAMENTOS[$_GET['pag'] ?? '']) ? $_GET['pag'] : '';
$furg = isset(URGENCIAS[$_GET['urg'] ?? '']) ? $_GET['urg'] : '';
$filtrando = ($q !== '' || $fpag !== '' || $furg !== '');
$pedidos = array_filter($todos, function ($p) use ($q, $fpag, $furg) {
    return ($q === '' || str_contains(mb_strtolower($p['cliente'] . ' ' . $p['descricao']), $q))
        && ($fpag === '' || $p['pagamento'] === $fpag)
        && ($furg === '' || $p['urgencia'] === $furg);
});

$porColuna = array_fill_keys(array_keys(COLUNAS), []);
foreach ($pedidos as $p) {
    $porColuna[$p['status']][] = $p;
}
foreach (['pendente', 'producao', 'pronto'] as $c) {
    usort($porColuna[$c], fn ($a, $b) => [$a['entrega'], $a['hora'], $rank[$a['urgencia']] ?? 3, $a['criado_em']]
                                     <=> [$b['entrega'], $b['hora'], $rank[$b['urgencia']] ?? 3, $b['criado_em']]);
}
usort($porColuna['entregue'], fn ($a, $b) => strcmp($b['concluido_em'] ?? '', $a['concluido_em'] ?? ''));

// Formulário: valores devolvidos se houve erro de validação
$flashForm = $_SESSION['flash_form'] ?? null;
unset($_SESSION['flash_form']);
$valores = is_array($flashForm['old'] ?? null) ? $flashForm['old'] : [];
$erros   = is_array($flashForm['erros'] ?? null) ? $flashForm['erros'] : [];

$movimentos = [   // botões por coluna: [destino, rótulo, classe]
    'pendente' => [['producao', 'Iniciar produção →', 'btn-pri']],
    'producao' => [['pronto', 'Pronto ✓', 'btn-pri'], ['pendente', '← Voltar', 'btn-sec']],
    'pronto'   => [['entregue', 'Entregue ✓', 'btn-pri'], ['producao', '← Voltar', 'btn-sec']],
    'entregue' => [['pronto', '← Reabrir', 'btn-sec']],
];

kanban_topo('Pedidos', 'pedidos');
?>
<section class="metricas" aria-label="Métricas financeiras (privadas)">
  <div class="metrica">
    <span class="metrica-rotulo">Pedidos entregues</span>
    <span class="metrica-valor"><?= $qtdEntregues ?></span>
  </div>
  <div class="metrica metrica-destaque">
    <span class="metrica-rotulo">Faturamento total</span>
    <span class="metrica-valor"><?= h(reais($faturamento)) ?></span>
    <span class="metrica-nota">soma dos pedidos na coluna Entregue</span>
  </div>
  <p class="privado">Dados confidenciais: aparecem somente nesta área.</p>
</section>

<details class="novo" id="novo-pedido"<?= ($erros || $valores) ? ' open' : '' ?>>
  <summary>Novo pedido</summary>
  <?php form_pedido($valores, 'adicionar', '', $erros); ?>
</details>

<form class="filtros-barra" method="get" action="painel.php" role="search" aria-label="Filtrar pedidos">
  <label class="campo f-busca">Buscar
    <input type="search" name="q" value="<?= h($_GET['q'] ?? '') ?>" placeholder="Cliente ou item" maxlength="60">
  </label>
  <label class="campo">Pagamento
    <select name="pag">
      <option value="">Todos</option>
      <?php foreach (PAGAMENTOS as $k => $r): ?><option value="<?= $k ?>"<?= $fpag === $k ? ' selected' : '' ?>><?= h($r) ?></option><?php endforeach; ?>
    </select>
  </label>
  <label class="campo">Urgência
    <select name="urg">
      <option value="">Todas</option>
      <?php foreach (URGENCIAS as $k => $r): ?><option value="<?= $k ?>"<?= $furg === $k ? ' selected' : '' ?>><?= h($r) ?></option><?php endforeach; ?>
    </select>
  </label>
  <button class="btn btn-peq" type="submit">Filtrar</button>
  <?php if ($filtrando): ?><a class="btn btn-peq btn-sec" href="painel.php">Limpar</a><?php endif; ?>
</form>

<section class="quadro" aria-label="Quadro de pedidos">
  <?php foreach (COLUNAS as $chave => $titulo): $lista = $porColuna[$chave]; ?>
  <div class="coluna coluna-<?= $chave ?>">
    <h2 class="coluna-titulo"><?= h($titulo) ?> <span class="coluna-n"><?= count($lista) ?></span></h2>
    <?php if (!$lista): ?><p class="vazio"><?= $filtrando ? 'Nenhum pedido com esses filtros.' : 'Nenhum pedido aqui.' ?></p><?php endif; ?>
    <?php foreach ($lista as $p):
        $aberto   = $chave !== 'entregue';
        $atrasado = $aberto && $p['entrega'] < $hoje;
        $ehHoje   = $aberto && $p['entrega'] === $hoje; ?>
    <article class="cartao urg-borda-<?= h($p['urgencia']) ?>">
      <div class="cartao-topo">
        <h3><?= h($p['cliente']) ?></h3>
        <span class="etq urg-<?= h($p['urgencia']) ?>"><?= h(URGENCIAS[$p['urgencia']] ?? '') ?></span>
      </div>
      <p class="cartao-desc"><?= nl2br(h($p['descricao'])) ?></p>
      <dl class="cartao-info">
        <div><dt>Valor</dt><dd><?= h(reais((int) $p['valor_centavos'])) ?></dd></div>
        <div><dt><?= $aberto ? 'Entregar em' : 'Entrega' ?></dt>
             <dd><?= h(data_br($p['entrega'])) ?><?= $p['hora'] !== '' ? ' · ' . h($p['hora']) : '' ?>
               <?php if ($atrasado): ?><span class="alerta">Atrasado</span><?php elseif ($ehHoje): ?><span class="alerta alerta-hoje">Hoje</span><?php endif; ?></dd></div>
        <div><dt>Pagamento</dt><dd><span class="pgto pgto-<?= h($p['pagamento']) ?>"><?= h(PAGAMENTOS[$p['pagamento']]) ?></span></dd></div>
      </dl>
      <div class="cartao-acoes">
        <?php foreach ($movimentos[$chave] as [$dest, $rotulo, $cls]): ?>
          <form method="post" action="acao.php">
            <?= csrf_campo() ?>
            <input type="hidden" name="acao" value="mover">
            <input type="hidden" name="id" value="<?= h($p['id']) ?>">
            <input type="hidden" name="destino" value="<?= $dest ?>">
            <button class="btn btn-peq <?= $cls ?>" type="submit"><?= h($rotulo) ?></button>
          </form>
        <?php endforeach; ?>
        <form method="post" action="acao.php">
          <?= csrf_campo() ?>
          <input type="hidden" name="acao" value="pagamento">
          <input type="hidden" name="id" value="<?= h($p['id']) ?>">
          <input type="hidden" name="valor" value="<?= $p['pagamento'] === 'pago' ? 'pendente' : 'pago' ?>">
          <button class="btn btn-peq btn-sec" type="submit"><?= $p['pagamento'] === 'pago' ? 'Marcar pendente' : 'Marcar pago' ?></button>
        </form>
        <a class="btn btn-peq btn-sec" href="editar.php?id=<?= h($p['id']) ?>">Editar</a>
        <details class="excluir">
          <summary class="btn btn-peq btn-sec">Excluir</summary>
          <form method="post" action="acao.php">
            <?= csrf_campo() ?>
            <input type="hidden" name="acao" value="excluir">
            <input type="hidden" name="id" value="<?= h($p['id']) ?>">
            <button class="btn btn-peq btn-perigo" type="submit">Confirmar exclusão</button>
          </form>
        </details>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <?php endforeach; ?>
</section>
<?php kanban_rodape();
