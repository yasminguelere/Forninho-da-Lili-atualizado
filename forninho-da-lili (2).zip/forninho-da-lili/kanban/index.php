<?php
declare(strict_types=1);

/* Página inicial do Kanban = formulário de login com a chave única. */

require __DIR__ . '/../nucleo/funcoes.php';
cabecalhos(true);
iniciar_sessao();

if (esta_logado()) {
    redirecionar('painel.php');
}

$erro = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $erro = tentar_login();
    if ($erro === null) {
        redirecionar('painel.php');
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<link rel="icon" href="../publico/fotos/logo.png">
<title>Entrar · Gestão do Forninho</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/kanban.css">
<script src="../publico/js/tema.js"></script>
</head>
<body class="entrada">
<main class="entrada-caixa">
  <div class="entrada-tema"><?= botao_tema() ?></div>
  <span class="logo-sigla logo-grande">FL</span>
  <h1>Gestão do Forninho</h1>
  <p class="mudo">Área privada. Pedidos e financeiro.</p>
  <?php if ($erro): ?><p class="aviso aviso-erro" role="alert"><?= h($erro) ?></p><?php endif; ?>
  <form method="post" action="index.php">
    <?= csrf_campo() ?>
    <label class="campo">Chave de acesso
      <input type="password" name="chave" required autofocus autocomplete="current-password" maxlength="200">
    </label>
    <button class="btn btn-cheio" type="submit">Entrar</button>
  </form>
</main>
</body>
</html>
