<?php
declare(strict_types=1);

/* Painel de aprovação das avaliações recebidas no site público. */

require __DIR__ . '/../nucleo/layout.php';
cabecalhos(true);
exigir_login();

const FILTROS = ['novo' => 'Novos', 'destaque' => 'Em destaque', 'oculto' => 'Ocultos', 'todos' => 'Todos'];
$filtro = isset(FILTROS[$_GET['f'] ?? '']) ? $_GET['f'] : 'novo';
$volta  = 'comentarios.php?f=' . $filtro;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valido()) {
        flash_set('erro', 'A página expirou. Tente de novo.');
        redirecionar($volta);
    }
    $acao = (string) ($_POST['acao'] ?? '');
    $id   = (string) ($_POST['id'] ?? '');
    $msg  = 'Pronto.';

    atualizar_dados('avaliacoes', function (array &$lista) use ($acao, $id, &$msg): void {
        foreach ($lista as $i => &$a) {
            if (($a['id'] ?? '') !== $id) {
                continue;
            }
            if ($acao === 'destacar') {
                $a['status'] = 'destaque';
                $msg = 'Comentário em destaque: agora aparece no site.';
            } elseif ($acao === 'ocultar') {
                $a['status'] = 'oculto';
                $msg = 'Comentário não será exibido no site.';
            } elseif ($acao === 'responder') {
                $resp = limpar_texto($_POST['resposta'] ?? '');
                $a['resposta'] = mb_substr($resp, 0, 500);
                $msg = $resp === '' ? 'Resposta removida.' : 'Resposta salva.';
            } elseif ($acao === 'excluir') {
                unset($lista[$i]);
                $msg = 'Comentário excluído.';
            }
            break;
        }
        $lista = array_values($lista);
    });
    flash_set('ok', $msg);
    redirecionar($volta);
}

$todas = ler_dados('avaliacoes');
$todas = array_reverse($todas); // desempate: o mais recente primeiro
usort($todas, fn ($a, $b) => strcmp($b['criado_em'] ?? '', $a['criado_em'] ?? ''));
$contagem = ['novo' => 0, 'destaque' => 0, 'oculto' => 0, 'todos' => count($todas)];
foreach ($todas as $a) {
    $contagem[$a['status'] ?? 'novo'] = ($contagem[$a['status'] ?? 'novo'] ?? 0) + 1;
}
$lista = $filtro === 'todos' ? $todas : array_values(array_filter($todas, fn ($a) => ($a['status'] ?? 'novo') === $filtro));
$rotuloStatus = ['novo' => 'Novo', 'destaque' => 'No site', 'oculto' => 'Oculto'];

kanban_topo('Comentários', 'comentarios');
?>
<h1 class="titulo-pagina">Comentários dos clientes</h1>
<p class="mudo">Só os comentários marcados como “em destaque” aparecem no site público, junto com a sua resposta.</p>

<nav class="filtros" aria-label="Filtrar comentários">
  <?php foreach (FILTROS as $k => $rot): ?>
    <a href="comentarios.php?f=<?= $k ?>"<?= $k === $filtro ? ' aria-current="true"' : '' ?>><?= h($rot) ?> <span class="coluna-n"><?= (int) ($contagem[$k] ?? 0) ?></span></a>
  <?php endforeach; ?>
</nav>

<?php if (!$lista): ?><p class="vazio vazio-grande">Nenhum comentário nesta lista.</p><?php endif; ?>

<div class="lista-com">
<?php foreach ($lista as $a): $st = $a['status'] ?? 'novo'; ?>
  <article class="com com-<?= h($st) ?>">
    <div class="com-topo">
      <div><b><?= h($a['nome']) ?></b> <span class="est" role="img" aria-label="Nota <?= (int) $a['nota'] ?> de 5"><?= h(estrelas((int) $a['nota'])) ?></span></div>
      <span class="etq etq-<?= h($st) ?>"><?= h($rotuloStatus[$st] ?? 'Novo') ?></span>
    </div>
    <p class="com-texto"><?= nl2br(h($a['comentario'])) ?></p>
    <p class="mudo pequeno">Enviado em <?= h(data_hora_br($a['criado_em'] ?? '')) ?></p>

    <form class="com-resp" method="post" action="<?= h($volta) ?>">
      <?= csrf_campo() ?>
      <input type="hidden" name="acao" value="responder">
      <input type="hidden" name="id" value="<?= h($a['id']) ?>">
      <label class="campo">Sua resposta (aparece no site se o comentário estiver em destaque)
        <textarea name="resposta" rows="2" maxlength="500"><?= h($a['resposta'] ?? '') ?></textarea>
      </label>
      <button class="btn btn-peq btn-sec" type="submit">Salvar resposta</button>
    </form>

    <div class="com-acoes">
      <?php if ($st !== 'destaque'): ?>
      <form method="post" action="<?= h($volta) ?>"><?= csrf_campo() ?>
        <input type="hidden" name="acao" value="destacar"><input type="hidden" name="id" value="<?= h($a['id']) ?>">
        <button class="btn btn-peq btn-pri" type="submit">Exibir no site</button></form>
      <?php endif; ?>
      <?php if ($st !== 'oculto'): ?>
      <form method="post" action="<?= h($volta) ?>"><?= csrf_campo() ?>
        <input type="hidden" name="acao" value="ocultar"><input type="hidden" name="id" value="<?= h($a['id']) ?>">
        <button class="btn btn-peq btn-sec" type="submit"><?= $st === 'destaque' ? 'Tirar do site' : 'Não exibir' ?></button></form>
      <?php endif; ?>
      <details class="excluir">
        <summary class="btn btn-peq btn-sec">Excluir</summary>
        <form method="post" action="<?= h($volta) ?>"><?= csrf_campo() ?>
          <input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= h($a['id']) ?>">
          <button class="btn btn-peq btn-perigo" type="submit">Confirmar exclusão</button></form>
      </details>
    </div>
  </article>
<?php endforeach; ?>
</div>
<?php kanban_rodape();
