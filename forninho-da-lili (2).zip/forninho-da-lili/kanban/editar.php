<?php
declare(strict_types=1);

require __DIR__ . '/../nucleo/layout.php';
cabecalhos(true);
exigir_login();

$id = (string) ($_GET['id'] ?? '');
$pedido = null;
foreach (ler_dados('pedidos') as $p) {
    if (($p['id'] ?? '') === $id) {
        $pedido = normalizar_pedido($p);
        break;
    }
}
if (!$pedido) {
    flash_set('erro', 'Pedido não encontrado.');
    redirecionar('painel.php');
}

$flashForm = $_SESSION['flash_form'] ?? null;
unset($_SESSION['flash_form']);
if (is_array($flashForm['old'] ?? null) && ($flashForm['id'] ?? '') === $id) {
    $valores = $flashForm['old'];
    $erros   = is_array($flashForm['erros'] ?? null) ? $flashForm['erros'] : [];
} else {
    $valores = [
        'cliente'   => $pedido['cliente'],
        'descricao' => $pedido['descricao'],
        'valor'     => number_format($pedido['valor_centavos'] / 100, 2, ',', '.'),
        'entrega'   => $pedido['entrega'],
        'hora'      => $pedido['hora'],
        'urgencia'  => $pedido['urgencia'],
        'pagamento' => $pedido['pagamento'],
    ];
    $erros = [];
}

kanban_topo('Editar pedido', 'pedidos');
?>
<h1 class="titulo-pagina">Editar pedido</h1>
<div class="painel-form"><?php form_pedido($valores, 'editar', $id, $erros); ?></div>
<?php kanban_rodape();
