<?php
declare(strict_types=1);

/* Recebe o formulário de avaliação do site público (POST) e grava como "novo" para a confeiteira aprovar. */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos();
iniciar_sessao();

const VOLTAR = 'index.php#avaliacoes';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar(VOLTAR);
}

$erro = static function (string $msg, array $old = []): never {
    flash_set('erro', $msg, ['old' => $old], 'publico');
    redirecionar(VOLTAR);
};

if (!csrf_valido()) {
    $erro('A página expirou. Envie o formulário de novo.');
}

// Isca para robôs: campo escondido que pessoas não preenchem
if (limpar_texto($_POST['site'] ?? '') !== '') {
    flash_set('ok', 'Obrigada pela avaliação!', [], 'publico');
    redirecionar(VOLTAR);
}

$nome       = preg_replace('/\s+/u', ' ', limpar_texto($_POST['nome'] ?? '')) ?? '';
$comentario = limpar_texto($_POST['comentario'] ?? '');
$nota       = filter_var($_POST['nota'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]);
$old        = ['nome' => $nome, 'comentario' => $comentario, 'nota' => $nota ?: 0];

if ($nota === false || $nota === null) {
    $erro('Escolha de 1 a 5 estrelas.', $old);
}
if (mb_strlen($nome) < 1 || mb_strlen($nome) > 60) {
    $erro('Informe seu nome (até 60 letras).', $old);
}
if (mb_strlen($comentario) < 3 || mb_strlen($comentario) > 500) {
    $erro('O comentário precisa ter entre 3 e 500 caracteres.', $old);
}

$ip = ip_hash();
$clienteId = cliente_logado()['id'] ?? '';
$agora = time();
$aceito = atualizar_dados('avaliacoes', function (array &$lista) use ($nome, $comentario, $nota, $ip, $agora, $clienteId): bool {
    $recentes = array_filter($lista, fn ($a) => ($a['ip'] ?? '') === $ip && ($a['ts'] ?? 0) > $agora - 3600);
    if (count($recentes) >= AVALIACOES_POR_HORA) {
        return false;
    }
    $lista[] = [
        'id'        => novo_id(),
        'nome'      => $nome,
        'nota'      => $nota,
        'comentario'=> $comentario,
        'resposta'  => '',
        'status'    => 'novo',          // novo | destaque | oculto
        'criado_em' => date('c', $agora),
        'ts'        => $agora,
        'ip'        => $ip,
        'cliente_id'=> $clienteId,
    ];
    return true;
});

if (!$aceito) {
    $erro('Você já enviou algumas avaliações há pouco. Tente de novo mais tarde.', $old);
}

flash_set('ok', 'Obrigada pela avaliação! Ela aparecerá no site depois de aprovada.', [], 'publico');
redirecionar(VOLTAR);
