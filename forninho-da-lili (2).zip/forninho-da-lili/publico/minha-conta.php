<?php
declare(strict_types=1);

/* Área do cliente: dados da conta e acompanhamento das avaliações enviadas. */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos(true);
iniciar_sessao();
$cliente = exigir_cliente();

$minhas = array_values(array_filter(ler_dados('avaliacoes'), fn ($a) => ($a['cliente_id'] ?? '') === $cliente['id']));
$minhas = array_reverse($minhas);
$rotulo = ['novo' => 'Aguardando aprovação', 'destaque' => 'Publicada no site', 'oculto' => 'Não exibida'];

$titulo = 'Minha conta';
include __DIR__ . '/partials/auth-topo.php';
?>
  <div class="conta-dados">
    <p><b><?= h($cliente['nome']) ?></b></p>
    <p><?= h($cliente['email']) ?></p>
    <p class="nota">Cliente desde <?= h(data_br($cliente['criado_em'])) ?></p>
  </div>
  <a class="btn" href="<?= h(link_whatsapp('Olá! Vim pelo site do ' . NOME_LOJA . ' e gostaria de fazer um pedido.')) ?>" target="_blank" rel="noopener noreferrer">Fazer um pedido no WhatsApp</a>
  <h2>Minhas avaliações</h2>
  <?php if (!$minhas): ?>
    <p class="nota alinha-esq">Você ainda não enviou avaliações. <a href="index.php#avaliacoes">Avaliar agora</a></p>
  <?php else: ?>
    <ul class="conta-lista">
      <?php foreach ($minhas as $a): ?>
        <li><span class="est-texto" role="img" aria-label="Nota <?= (int) $a['nota'] ?> de 5"><?= h(estrelas((int) $a['nota'])) ?></span>
          <?= h($a['comentario']) ?>
          <small><?= h($rotulo[$a['status'] ?? 'novo'] ?? '') ?><?= !empty($a['resposta']) ? ' · Dani respondeu: ' . h($a['resposta']) : '' ?></small></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
  <form method="post" action="sair.php"><?= csrf_campo() ?><button class="btn btn-contorno" type="submit">Sair da conta</button></form>
  <p class="nota"><a href="index.php">Voltar ao site</a></p>
<?php include __DIR__ . '/partials/auth-rodape.php';
