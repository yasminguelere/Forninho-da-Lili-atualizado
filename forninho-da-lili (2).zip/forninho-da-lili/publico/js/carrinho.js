/*
 * Carrinho de compras do Forninho da Lili (sem bibliotecas).
 *
 * - O estado fica no localStorage, então não se perde ao navegar entre páginas nem ao recarregar.
 * - Os produtos vêm do HTML do cardápio: <button data-add data-id data-nome data-preco>.
 *   Preços e nomes são sempre reconferidos com o cardápio atual da página.
 * - Subtotal, entrega e total são recalculados a cada mudança.
 * - "Finalizar" monta o resumo e abre o WhatsApp da confeitaria com a mensagem pronta.
 * - Nada do que vem do navegador é inserido como HTML (só textContent), então não há injeção.
 */
(function () {
  'use strict';

  var raiz = document.getElementById('carrinho-raiz');
  if (!raiz) { return; }

  var CHAVE = 'forninho_carrinho_v1';
  var MAX_QTD = 99;
  var cfg = {
    whatsapp: raiz.dataset.whatsapp,
    loja: raiz.dataset.loja,
    entregaAtiva: raiz.dataset.entregaAtiva === '1',
    taxa: parseFloat(raiz.dataset.taxa) || 0
  };
  var moeda = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  /** Valor em reais com espaço comum (o formato do navegador usa espaço não separável, ruim no WhatsApp). */
  function brl(v) { return moeda.format(v).replace(/\u00a0/g, ' '); }

  var el = {
    dialogo: document.getElementById('carrinho'),
    lista: document.getElementById('carrinho-itens'),
    vazio: document.getElementById('carrinho-vazio'),
    corpo: document.getElementById('carrinho-corpo'),
    subtotal: document.getElementById('carrinho-subtotal'),
    taxa: document.getElementById('carrinho-taxa'),
    total: document.getElementById('carrinho-total'),
    nome: document.getElementById('cli-nome'),
    data: document.getElementById('cli-data'),
    hora: document.getElementById('cli-hora'),
    obs: document.getElementById('cli-obs'),
    enviar: document.getElementById('carrinho-enviar'),
    dica: document.getElementById('carrinho-dica'),
    limpar: document.getElementById('carrinho-limpar'),
    status: document.getElementById('carrinho-status'),
    contadores: document.querySelectorAll('[data-carrinho-contador]')
  };

  /* ---------- Estado (id -> {n: nome, p: preço, q: quantidade}) ---------- */

  function ler() {
    try {
      var d = JSON.parse(localStorage.getItem(CHAVE));
      return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
    } catch (e) { return {}; }
  }
  function gravar() {
    try { localStorage.setItem(CHAVE, JSON.stringify(estado)); } catch (e) { /* sem armazenamento: vale só nesta página */ }
  }
  var estado = ler();

  /** Confere o carrinho salvo com o cardápio da página (preço novo, produto removido, quantidade válida). */
  function reconciliar() {
    var catalogo = {};
    document.querySelectorAll('[data-add]').forEach(function (b) {
      catalogo[b.dataset.id] = { n: b.dataset.nome, p: parseFloat(b.dataset.preco) };
    });
    var temCatalogo = Object.keys(catalogo).length > 0;
    Object.keys(estado).forEach(function (id) {
      var item = estado[id];
      var q = parseInt(item && item.q, 10);
      if (!item || !(q >= 1)) { delete estado[id]; return; }
      item.q = Math.min(q, MAX_QTD);
      if (temCatalogo) {
        if (!catalogo[id]) { delete estado[id]; return; }
        item.n = catalogo[id].n;
        item.p = catalogo[id].p;
      } else if (typeof item.n !== 'string' || !(item.p >= 0)) {
        delete estado[id];
      }
    });
    gravar();
  }

  /* ---------- Cálculos ---------- */

  function subtotal() {
    return Object.keys(estado).reduce(function (s, id) { return s + estado[id].p * estado[id].q; }, 0);
  }
  function quantidadeTotal() {
    return Object.keys(estado).reduce(function (s, id) { return s + estado[id].q; }, 0);
  }
  function modoEntrega() {
    var r = raiz.querySelector('input[name="entrega"]:checked');
    return r && r.value === 'entrega' && cfg.entregaAtiva ? 'entrega' : 'retirada';
  }
  function taxaEntrega() { return modoEntrega() === 'entrega' ? cfg.taxa : 0; }

  /* ---------- Desenho da tela ---------- */

  function criar(tag, classe, texto) {
    var e = document.createElement(tag);
    if (classe) { e.className = classe; }
    if (texto !== undefined) { e.textContent = texto; }
    return e;
  }
  function botao(texto, rotulo, acao, id) {
    var b = criar('button', 'qtd-btn', texto);
    b.type = 'button';
    b.setAttribute('aria-label', rotulo);
    b.dataset.acao = acao;
    b.dataset.id = id;
    return b;
  }

  function desenhar() {
    var ids = Object.keys(estado);
    el.lista.textContent = '';

    ids.forEach(function (id) {
      var it = estado[id];
      var li = criar('li', 'item');
      var info = criar('div', 'item-info');
      info.appendChild(criar('b', null, it.n));
      info.appendChild(criar('small', null, moeda.format(it.p) + ' cada'));

      var qtd = criar('div', 'item-qtd');
      qtd.appendChild(botao('−', 'Diminuir quantidade de ' + it.n, 'menos', id));
      var n = criar('span', 'qtd-n', String(it.q));
      n.setAttribute('aria-label', it.q + ' unidades');
      qtd.appendChild(n);
      qtd.appendChild(botao('+', 'Aumentar quantidade de ' + it.n, 'mais', id));

      var fim = criar('div', 'item-fim');
      fim.appendChild(criar('b', null, moeda.format(it.p * it.q)));
      var rem = criar('button', 'remover', 'Remover');
      rem.type = 'button';
      rem.setAttribute('aria-label', 'Remover ' + it.n + ' do carrinho');
      rem.dataset.acao = 'remover';
      rem.dataset.id = id;
      fim.appendChild(rem);

      li.appendChild(info); li.appendChild(qtd); li.appendChild(fim);
      el.lista.appendChild(li);
    });

    var vazio = ids.length === 0;
    el.vazio.hidden = !vazio;
    el.lista.hidden = vazio;
    el.corpo.hidden = vazio;

    var sub = subtotal(), taxa = taxaEntrega();
    el.subtotal.textContent = moeda.format(sub);
    el.taxa.textContent = moeda.format(taxa);
    el.total.textContent = moeda.format(sub + taxa);

    var qtd = quantidadeTotal();
    el.contadores.forEach(function (c) { c.textContent = String(qtd); c.hidden = qtd === 0; });
    atualizarEnvio();
  }

  /* ---------- Mensagem do WhatsApp ---------- */

  function dataBR(iso) {
    var p = (iso || '').split('-');
    return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : '';
  }

  function montarMensagem() {
    var linhas = ['Olá! Vim pelo site do ' + cfg.loja + ' e gostaria de fazer um pedido:', ''];
    Object.keys(estado).forEach(function (id) {
      var it = estado[id];
      linhas.push('• ' + it.q + 'x ' + it.n + ' — ' + brl(it.p * it.q));
    });
    var sub = subtotal(), taxa = taxaEntrega();
    linhas.push('');
    linhas.push('Subtotal: ' + brl(sub));
    linhas.push((modoEntrega() === 'entrega' ? 'Entrega' : 'Retirada no local') + ': ' + brl(taxa));
    linhas.push('Total: ' + brl(sub + taxa));
    linhas.push('');
    linhas.push('Nome: ' + el.nome.value.trim());
    var quando = [dataBR(el.data.value), el.hora.value].filter(Boolean).join(' às ');
    if (quando) { linhas.push((modoEntrega() === 'entrega' ? 'Entrega: ' : 'Retirada: ') + quando); }
    if (el.obs.value.trim()) { linhas.push('Obs.: ' + el.obs.value.trim()); }
    return linhas.join('\n');
  }

  function atualizarEnvio() {
    var pronto = Object.keys(estado).length > 0 && el.nome.value.trim() !== '';
    el.enviar.setAttribute('aria-disabled', pronto ? 'false' : 'true');
    el.dica.hidden = pronto;
    el.enviar.href = pronto
      ? 'https://wa.me/' + cfg.whatsapp + '?text=' + encodeURIComponent(montarMensagem())
      : '#';
  }

  /* ---------- Ações ---------- */

  function avisar(texto) { el.status.textContent = ''; setTimeout(function () { el.status.textContent = texto; }, 30); }

  function adicionar(id, nome, preco) {
    var it = estado[id] || { n: nome, p: preco, q: 0 };
    it.n = nome; it.p = preco;
    it.q = Math.min(it.q + 1, MAX_QTD);
    estado[id] = it;
    gravar(); desenhar();
    avisar(nome + ' adicionado ao carrinho. ' + quantidadeTotal() + ' itens no total.');
  }

  function mudar(id, acao) {
    var it = estado[id];
    if (!it) { return; }
    if (acao === 'mais') { it.q = Math.min(it.q + 1, MAX_QTD); }
    if (acao === 'menos') { it.q -= 1; }
    if (acao === 'remover' || it.q < 1) { delete estado[id]; }
    gravar(); desenhar();
  }

  // Produtos do cardápio
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-add]');
    if (b) {
      adicionar(b.dataset.id, b.dataset.nome, parseFloat(b.dataset.preco));
      var antes = b.textContent;
      b.textContent = 'Adicionado ✓';
      setTimeout(function () { b.textContent = antes; }, 1100);
      return;
    }
    if (e.target.closest('[data-abrir-carrinho]')) { desenhar(); el.dialogo.showModal(); }
  });

  // Quantidade / remover (delegação)
  el.lista.addEventListener('click', function (e) {
    var b = e.target.closest('[data-acao]');
    if (b) { mudar(b.dataset.id, b.dataset.acao); }
  });

  // Fechar: botão, clique fora da gaveta ou Esc (nativo do <dialog>)
  raiz.querySelector('[data-fechar-carrinho]').addEventListener('click', function () { el.dialogo.close(); });
  el.dialogo.addEventListener('click', function (e) { if (e.target === el.dialogo) { el.dialogo.close(); } });

  // Entrega, dados do cliente
  raiz.querySelectorAll('input[name="entrega"]').forEach(function (r) { r.addEventListener('change', desenhar); });
  [el.nome, el.data, el.hora, el.obs].forEach(function (c) { c.addEventListener('input', atualizarEnvio); });

  // Encomendas com 2 dias de antecedência: a data mínima é hoje + 2
  (function () {
    var d = new Date(); d.setDate(d.getDate() + 2);
    var mm = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
    el.data.min = d.getFullYear() + '-' + mm + '-' + dd;
  })();

  // Impede o clique no botão "desativado"
  el.enviar.addEventListener('click', function (e) {
    if (el.enviar.getAttribute('aria-disabled') === 'true') { e.preventDefault(); el.nome.focus(); }
  });

  el.limpar.addEventListener('click', function () {
    estado = {}; gravar(); desenhar();
    avisar('Carrinho esvaziado.');
  });

  // Mantém várias abas sincronizadas
  window.addEventListener('storage', function (e) {
    if (e.key === CHAVE) { estado = ler(); desenhar(); }
  });

  reconciliar();
  desenhar();
})();
