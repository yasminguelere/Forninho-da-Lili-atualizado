/*
 * Alternador de tema claro/escuro.
 * - Carregado no <head> (sem defer) para aplicar o tema ANTES da página aparecer, sem piscar.
 * - A escolha fica no localStorage do navegador e vale para todas as páginas.
 * - Padrão: tema claro.
 */
(function () {
  'use strict';
  var CHAVE = 'forninho_tema';
  var raiz = document.documentElement;
  raiz.classList.add('js'); // libera os elementos que só funcionam com JavaScript

  function ler() {
    try { return localStorage.getItem(CHAVE); } catch (e) { return null; }
  }
  function aplicar(tema) {
    raiz.setAttribute('data-theme', tema === 'dark' ? 'dark' : 'light');
  }

  aplicar(ler()); // tema salvo (ou claro)

  document.addEventListener('DOMContentLoaded', function () {
    var botoes = document.querySelectorAll('[data-tema-toggle]');

    function atualizar() {
      var escuro = raiz.getAttribute('data-theme') === 'dark';
      botoes.forEach(function (b) {
        b.setAttribute('aria-pressed', escuro ? 'true' : 'false');
        b.setAttribute('aria-label', escuro ? 'Mudar para tema claro' : 'Mudar para tema escuro');
        b.title = escuro ? 'Tema claro' : 'Tema escuro';
      });
    }

    botoes.forEach(function (b) {
      b.addEventListener('click', function () {
        var novo = raiz.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        aplicar(novo);
        try { localStorage.setItem(CHAVE, novo); } catch (e) { /* navegação privada: vale só nesta página */ }
        atualizar();
      });
    });

    // Mantém várias abas sincronizadas
    window.addEventListener('storage', function (e) {
      if (e.key === CHAVE) { aplicar(e.newValue); atualizar(); }
    });
    atualizar();
  });
})();
