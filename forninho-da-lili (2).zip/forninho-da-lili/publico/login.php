<?php
declare(strict_types=1);

/* Entrar (cliente cadastrado). Depois do login vai para REDIRECT_POS_LOGIN_CLIENTE (config.php). */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos(true);
iniciar_sessao();

if (cliente_logado()) {
    redirecionar(REDIRECT_POS_LOGIN_CLIENTE);
}

$erro  = null;
$email = '';
$aviso = flash_get('conta');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = normalizar_email($_POST['email'] ?? '');
    $senha = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
    $erro  = tentar_login_cliente($email, $senha);
    if ($erro === null) {
        redirecionar(REDIRECT_POS_LOGIN_CLIENTE);
    }
}

$titulo = 'Entrar';
include __DIR__ . '/partials/auth-topo.php';
?>
  <p class="nota">Acesse sua conta para avaliar com seu nome e acompanhar seus comentários.</p>
  <?php if ($aviso): ?><p class="msg msg-<?= h($aviso['tipo']) ?>" role="status"><?= h($aviso['msg']) ?></p><?php endif; ?>
  <?php if ($erro): ?><p class="msg msg-erro" role="alert"><?= h($erro) ?></p><?php endif; ?>
  <form method="post" action="login.php">
    <?= csrf_campo() ?>
    <label class="campo">E-mail
      <input type="email" name="email" required autofocus autocomplete="email" maxlength="120" value="<?= h($email) ?>">
    </label>
    <label class="campo">Senha
      <input type="password" name="senha" required autocomplete="current-password" maxlength="200">
    </label>
    <button class="btn" type="submit">Entrar</button>
  </form>
  <p class="auth-links"><a href="esqueci-senha.php">Esqueci minha senha</a><a href="cadastro.php">Criar conta</a></p>
  <p class="nota"><a href="index.php">Voltar ao site</a></p>
<?php include __DIR__ . '/partials/auth-rodape.php';
