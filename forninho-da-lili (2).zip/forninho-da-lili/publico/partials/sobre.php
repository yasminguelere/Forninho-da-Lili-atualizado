<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<section id="sobre" class="sobre-sec"><div class="wrap sobre">
  <div class="moldura moldura-logo"><img src="fotos/logo.png" alt="Logo do Forninho da Lili: menina confeiteira de avental rosa segurando um bolo"></div>
  <div>
    <span class="sobretitulo">Quem faz</span>
    <h2>A história do Forninho da Lili</h2>
    <p>O Forninho da Lili nasceu de um sonho que, com carinho, dedicação e muito amor, ganhou vida.</p>
    <p>Mais do que doces, queremos transformar pequenos momentos em memórias especiais. Que cada delícia leve consigo a alegria de uma comemoração, o carinho de um gesto ou aquele aconchego que o coração procura nos dias mais difíceis.</p>
    <p>Porque acreditamos que, às vezes, um pedacinho de doçura é tudo o que precisamos para tornar o dia mais leve, o momento mais bonito e a vida um pouquinho mais doce.</p>
    <p class="fecho">Forninho da Lili: feito com amor para adoçar momentos e criar memórias.</p>
    <p class="assina">Com carinho, Dani</p>
  </div>
</div></section>
