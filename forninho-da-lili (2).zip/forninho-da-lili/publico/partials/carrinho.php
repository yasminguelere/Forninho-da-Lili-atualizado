<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Carrinho (gaveta lateral). Só é usado com JavaScript: js/carrinho.js preenche e calcula tudo. */ ?>
<div id="carrinho-raiz" class="so-js"
     data-whatsapp="<?= h(WHATSAPP_NUMERO) ?>" data-loja="<?= h(NOME_LOJA) ?>"
     data-entrega-ativa="<?= ENTREGA_ATIVA ? '1' : '0' ?>" data-taxa="<?= h(number_format(ENTREGA_TAXA, 2, '.', '')) ?>">
  <p class="sr" id="carrinho-status" role="status" aria-live="polite"></p>

  <dialog class="carrinho" id="carrinho" aria-labelledby="carrinho-titulo">
    <div class="carrinho-in">
      <div class="carrinho-topo">
        <h2 id="carrinho-titulo">Seu carrinho</h2>
        <button class="btn-fechar" type="button" data-fechar-carrinho aria-label="Fechar carrinho">✕</button>
      </div>

      <p class="carrinho-vazio" id="carrinho-vazio">Seu carrinho está vazio. Escolha algo gostoso no cardápio.</p>
      <ul class="carrinho-itens" id="carrinho-itens"></ul>

      <div class="carrinho-corpo" id="carrinho-corpo" hidden>
        <fieldset class="carrinho-entrega">
          <legend>Como receber</legend>
          <label class="opcao"><input type="radio" name="entrega" value="retirada" checked>
            <span>Retirada no local <small>sem custo</small></span></label>
          <?php if (ENTREGA_ATIVA): ?>
          <label class="opcao"><input type="radio" name="entrega" value="entrega">
            <span>Entrega <small>taxa de <?= h(reais_float(ENTREGA_TAXA)) ?></small></span></label>
          <?php endif; ?>
        </fieldset>

        <dl class="carrinho-totais" aria-label="Valores">
          <div><dt>Subtotal</dt><dd id="carrinho-subtotal">R$ 0,00</dd></div>
          <div><dt>Entrega</dt><dd id="carrinho-taxa">R$ 0,00</dd></div>
          <div class="total"><dt>Total</dt><dd id="carrinho-total">R$ 0,00</dd></div>
        </dl>

        <label class="campo">Seu nome
          <input id="cli-nome" maxlength="60" autocomplete="name" value="<?= h($cliente['nome'] ?? '') ?>">
        </label>
        <div class="linha-2">
          <label class="campo">Data de retirada
            <input id="cli-data" type="date">
          </label>
          <label class="campo">Horário
            <input id="cli-hora" type="time">
          </label>
        </div>
        <label class="campo">Observações
          <textarea id="cli-obs" rows="2" maxlength="200" placeholder="Recado, restrição alimentar..."></textarea>
        </label>
        <p class="nota">Encomendas com 2 dias de antecedência. O pedido só é confirmado depois que a Dani responder no WhatsApp.</p>

        <a class="btn btn-whats" id="carrinho-enviar" href="#" target="_blank" rel="noopener noreferrer" aria-disabled="true">Enviar pedido pelo WhatsApp</a>
        <p class="nota" id="carrinho-dica">Informe seu nome para enviar.</p>
        <button class="btn-link-claro" type="button" id="carrinho-limpar">Limpar carrinho</button>
      </div>
    </div>
  </dialog>
</div>
