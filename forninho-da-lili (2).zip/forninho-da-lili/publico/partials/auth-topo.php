<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Casca das telas de conta do cliente. Usa: $titulo */ ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<link rel="icon" href="fotos/logo.png">
<title><?= h($titulo) ?> · Forninho da Lili</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Dancing+Script:wght@600;700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/auth.css">
<script src="js/tema.js"></script>
</head>
<body class="pagina-auth">
<main class="auth-caixa">
  <div class="auth-tema"><?= botao_tema() ?></div>
  <a class="marca" href="index.php"><img class="selo" src="fotos/logo.png" alt=""><span>Forninho da Lili</span></a>
  <h1><?= h($titulo) ?></h1>
