<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Novidades e atendimento. Usa: $novidades */ ?>
<section class="sec" id="novidades"><div class="wrap">
  <h2>Novidades e próximas mudanças</h2>
  <p class="sub">Fique por dentro do que está chegando ao Forninho da Lili.</p>
  <div class="novidades">
    <?php foreach ($novidades as $n): ?>
      <article class="novidade">
        <span class="etiqueta"><?= h($n['etiqueta']) ?></span>
        <h3><?= h($n['titulo']) ?></h3>
        <p><?= h($n['texto']) ?></p>
      </article>
    <?php endforeach; ?>
    <article class="novidade atendimento">
      <h3>Atendimento</h3>
      <p><b><?= h(HORARIO) ?></b></p>
      <p class="nota">Pedidos e dúvidas pelo WhatsApp <?= h(WHATSAPP_EXIBIR) ?>.</p>
      <a class="btn" href="<?= h(link_whatsapp('Olá! Vim pelo site do ' . NOME_LOJA . ' e gostaria de tirar uma dúvida.')) ?>" target="_blank" rel="noopener noreferrer">Chamar no WhatsApp</a>
    </article>
  </div>
</div></section>
