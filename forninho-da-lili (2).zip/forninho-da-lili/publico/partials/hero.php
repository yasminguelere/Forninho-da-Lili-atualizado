<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Banner principal. Usa: $msgGeral */ ?>
<div class="wrap hero" id="inicio">
  <div>
    <span class="sobretitulo">Confeitaria artesanal</span>
    <h1>Forninho da Lili</h1>
    <p class="lema">Doces feitos à mão, com carinho</p>
    <p>Pequenas fornadas, ingredientes selecionados e cuidado em cada detalhe. Escolha no cardápio, monte o carrinho e envie o pedido pelo WhatsApp. <?= ENTREGA_ATIVA ? 'Retire com a gente ou receba em casa.' : 'A retirada é feita com a gente.' ?></p>
    <div class="acoes">
      <a class="btn" href="#cardapio">Ver cardápio</a>
      <a class="btn btn-contorno" href="<?= h(link_whatsapp($msgGeral)) ?>" target="_blank" rel="noopener noreferrer">Pedir no WhatsApp</a>
    </div>
  </div>
  <div class="moldura"><img src="fotos/embalagens.jpg" alt="Embalagens com laço rosa e potinhos de vidro com biscoitos e brownies, com o selo do Forninho da Lili"></div>
</div>

<div class="wrap"><div class="aviso" role="note">
<?php if (ENTREGA_ATIVA): ?>
  <b>Retirada ou entrega:</b> combine tudo pelo WhatsApp. A entrega tem taxa de <b><?= h(reais_float(ENTREGA_TAXA)) ?></b>, e a retirada é sem custo.
<?php else: ?>
  <b>Atenção:</b> o Forninho da Lili <b>não faz entregas</b>. Todos os pedidos são <b>retirados com a confeiteira, no local combinado pelo WhatsApp</b>, em data e horário combinados.
<?php endif; ?>
</div></div>
