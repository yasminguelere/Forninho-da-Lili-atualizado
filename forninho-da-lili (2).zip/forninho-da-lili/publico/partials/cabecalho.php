<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Faixa de aviso + cabeçalho com navegação (âncoras de rolagem suave). Usa: $cliente */ ?>
<a class="pular" href="#cardapio">Pular para o cardápio</a>
<div class="faixa"><?= ENTREGA_ATIVA ? 'Retirada ou entrega combinada pelo WhatsApp' : 'Não fazemos entrega · Retirada combinada pelo WhatsApp' ?> · Encomendas com 2 dias de antecedência</div>

<header class="cabecalho"><div class="wrap nav">
  <a class="marca" href="#inicio"><img class="selo" src="fotos/logo.png" alt=""><span>Forninho da Lili</span></a>
  <nav class="links" aria-label="Principal">
    <a href="#inicio">Início</a><a href="#como">Como pedir</a><a href="#cardapio">Cardápio</a><a href="#galeria">Fotos</a>
    <a href="#novidades">Novidades</a><a href="#avaliacoes">Avaliações</a><a href="#sobre">Sobre</a>
    <?php if ($cliente): ?>
      <a class="link-conta" href="minha-conta.php">Minha conta</a>
    <?php else: ?>
      <a class="link-conta" href="login.php">Entrar</a>
    <?php endif; ?>
  </nav>
  <div class="nav-acoes">
    <?= botao_tema() ?>
    <button class="btn-carrinho so-js" type="button" data-abrir-carrinho aria-haspopup="dialog">
      <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M7 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM3 2v2h2l3.6 7.6-1.4 2.4A2 2 0 0 0 9 17h11v-2H9.4l1.1-2h7.5a2 2 0 0 0 1.7-1l3.6-6.5A1 1 0 0 0 22.4 4H6.2l-.9-2H3z"/></svg>
      <span>Carrinho</span><span class="contador" data-carrinho-contador aria-live="polite">0</span>
    </button>
  </div>
</div></header>
