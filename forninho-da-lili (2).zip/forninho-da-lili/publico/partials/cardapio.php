<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Cardápio por categorias, com <details> retráteis. Usa: $cardapio */ ?>
<section class="sec" id="cardapio"><div class="wrap">
  <h2>Cardápio</h2>
  <p class="sub">Toque em “Detalhes” para ver tamanho e aviso de alergênicos. Adicione ao carrinho e envie o pedido pelo WhatsApp.</p>
  <div class="categorias">
    <?php foreach ($cardapio as $cat => $itens): ?>
      <a class="categoria" href="#c-<?= h(slug($cat)) ?>"><div><h3><?= h($cat) ?></h3><small><?= count($itens) ?> <?= count($itens) === 1 ? 'item' : 'itens' ?></small></div></a>
    <?php endforeach; ?>
  </div>
</div></section>

<?php foreach ($cardapio as $cat => $itens): ?>
<section class="secao-cat" id="c-<?= h(slug($cat)) ?>"><div class="wrap">
  <h2><?= h($cat) ?></h2>
  <div class="grade">
    <?php foreach ($itens as $p):
        $msg = 'Olá! Vim pelo site do ' . NOME_LOJA . ' e gostaria de pedir: ' . $p['nome'] . ' (' . reais_float((float) $p['preco']) . ').'; ?>
    <article class="prod">
      <?php if (!empty($p['foto'])): ?>
        <div class="prod-foto"><img src="fotos/<?= h($p['foto']) ?>" alt="<?= h($p['alt'] ?? $p['nome']) ?>" loading="lazy"></div>
      <?php endif; ?>
      <div class="prod-corpo">
        <h3><?= h($p['nome']) ?></h3>
        <p><?= h($p['descricao']) ?></p>
        <details>
          <summary>Detalhes</summary>
          <?php if (!empty($p['tamanho'])): ?><p><b>Tamanho:</b> <?= h($p['tamanho']) ?></p><?php endif; ?>
          <?php if (!empty($p['ingredientes'])): ?><p><b>Ingredientes:</b> <?= h($p['ingredientes']) ?></p><?php endif; ?>
          <p class="nota"><?= h(AVISO_ALERGENOS) ?></p>
        </details>
        <div class="prod-rodape">
          <b><?= h(reais_float((float) $p['preco'])) ?></b>
          <button class="btn btn-pequeno so-js" type="button" data-add
                  data-id="<?= h(slug($p['nome'])) ?>" data-nome="<?= h($p['nome']) ?>" data-preco="<?= h(number_format((float) $p['preco'], 2, '.', '')) ?>">Adicionar</button>
          <a class="btn btn-pequeno so-nojs" href="<?= h(link_whatsapp($msg)) ?>" target="_blank" rel="noopener noreferrer">Pedir no WhatsApp</a>
        </div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
</div></section>
<?php endforeach; ?>
