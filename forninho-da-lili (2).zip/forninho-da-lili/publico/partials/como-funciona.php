<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<section class="sec" id="como"><div class="wrap">
  <h2>Pedir é simples</h2><p class="sub">Quatro passos, sem cadastro.</p>
  <ol class="passos">
    <li><b>1</b>Escolha os doces e adicione ao carrinho</li>
    <li><b>2</b>Confira o resumo e toque em “Enviar pelo WhatsApp”</li>
    <li><b>3</b>Combine data, horário e retirada com a Dani</li>
    <li><b>4</b>Pague por Pix e <?= ENTREGA_ATIVA ? 'retire ou receba' : 'retire no local' ?></li>
  </ol>
</div></section>
