<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Rodapé institucional + botão flutuante do WhatsApp. Usa: $msgGeral, $cliente */ ?>
<footer class="rodape"><div class="wrap">
  <div class="rodape-grade">
    <div>
      <a class="marca marca-rodape" href="#inicio"><img class="selo" src="fotos/logo.png" alt=""><span>Forninho da Lili</span></a>
      <p>Confeitaria artesanal feita com carinho, sob encomenda.</p>
    </div>
    <div><h4>Navegue</h4><a href="#como">Como pedir</a><a href="#cardapio">Cardápio</a><a href="#galeria">Fotos</a><a href="#novidades">Novidades</a><a href="#avaliacoes">Avaliações</a><a href="#sobre">Sobre</a></div>
    <div><h4>Atendimento</h4><p><?= h(HORARIO) ?></p><p><?= ENTREGA_ATIVA ? '<b>Retirada ou entrega</b>' : '<b>Sem entrega</b> · só retirada' ?></p></div>
    <div><h4>Contato</h4><a href="<?= h(link_whatsapp($msgGeral)) ?>" target="_blank" rel="noopener noreferrer">WhatsApp <?= h(WHATSAPP_EXIBIR) ?></a>
      <?php if ($cliente): ?><a href="minha-conta.php">Minha conta</a><?php else: ?><a href="login.php">Entrar ou criar conta</a><?php endif; ?></div>
  </div>
  <div class="direitos">© <?= date('Y') ?> Forninho da Lili · Feito com carinho pela Dani <a class="acesso-discreto" href="<?= h(URL_KANBAN) ?>index.php" aria-label="Acesso restrito" rel="nofollow"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7zm9 4.2v-1.4l-2-.6a7 7 0 0 0-.6-1.5l1-1.8-1-1-1.8 1a7 7 0 0 0-1.5-.6l-.6-2h-1.4l-.6 2a7 7 0 0 0-1.5.6l-1.8-1-1 1 1 1.8c-.3.5-.5 1-.6 1.5l-2 .6v1.4l2 .6c.1.5.3 1 .6 1.5l-1 1.8 1 1 1.8-1c.5.3 1 .5 1.5.6l.6 2h1.4l.6-2c.5-.1 1-.3 1.5-.6l1.8 1 1-1-1-1.8c.3-.5.5-1 .6-1.5l2-.6z" opacity=".9"/></svg></a></div>
</div></footer>

<a class="wa-fixo" href="<?= h(link_whatsapp($msgGeral)) ?>" target="_blank" rel="noopener noreferrer">
  <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2C6.5 2 2 6.1 2 11.2c0 2.3.9 4.4 2.5 6L3.6 22l4.9-1.9c1.1.4 2.3.6 3.5.6 5.5 0 10-4.1 10-9.2S17.5 2 12 2z"/></svg>
  <span>Pedir no WhatsApp</span>
</a>
