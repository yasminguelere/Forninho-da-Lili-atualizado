<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Galeria + lightbox em CSS puro (:target). Usa: $fotos */ ?>
<section class="sec" id="galeria"><div class="wrap">
  <h2>Um pouquinho do nosso forninho</h2><p class="sub">Toque em uma foto para ver maior.</p>
  <div class="galeria">
    <?php foreach ($fotos as $i => $f): ?>
      <a class="gal-item" href="#foto-<?= $i + 1 ?>"><img src="fotos/<?= h($f['arq']) ?>" alt="<?= h($f['alt']) ?>" loading="lazy"></a>
    <?php endforeach; ?>
  </div>
</div></section>

<?php foreach ($fotos as $i => $f): ?>
  <a class="lightbox" id="foto-<?= $i + 1 ?>" href="#galeria" aria-label="Fechar foto ampliada">
    <img src="fotos/<?= h($f['arq']) ?>" alt="<?= h($f['alt']) ?>">
    <span class="lightbox-fechar">Fechar</span>
  </a>
<?php endforeach; ?>
