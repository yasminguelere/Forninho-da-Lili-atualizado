<?php if (!function_exists('h')) { http_response_code(404); exit; } ?>
<?php /* Mural (só avaliações aprovadas) + formulário. Usa: $aprovadas, $flash, $old, $cliente */ ?>
<section class="sec" id="avaliacoes"><div class="wrap">
  <h2>O que dizem sobre o Forninho</h2>
  <p class="sub">Conte como foi a sua experiência. Os comentários escolhidos pela Dani aparecem aqui.</p>

  <?php if ($aprovadas): ?>
    <div class="grade-av">
      <?php foreach ($aprovadas as $a): ?>
        <article class="avaliacao">
          <div class="av-topo"><b><?= h($a['nome']) ?></b><span class="est-texto" role="img" aria-label="Nota <?= (int) $a['nota'] ?> de 5"><?= h(estrelas((int) $a['nota'])) ?></span></div>
          <p><?= nl2br(h($a['comentario'])) ?></p>
          <?php if (!empty($a['resposta'])): ?>
            <div class="resposta"><b>Resposta da Dani</b><p><?= nl2br(h($a['resposta'])) ?></p></div>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p class="nota centro">Os primeiros comentários aparecerão aqui depois de aprovados pela confeiteira.</p>
  <?php endif; ?>

  <form class="form-av" method="post" action="avaliar.php" id="form-avaliacao">
    <h3>Deixe sua avaliação</h3>
    <?php if ($flash): ?>
      <p class="msg msg-<?= h($flash['tipo']) ?>" role="status"><?= h($flash['msg']) ?></p>
    <?php endif; ?>
    <?= csrf_campo() ?>
    <fieldset>
      <legend>Sua nota</legend>
      <div class="estrelas">
        <?php for ($n = 5; $n >= 1; $n--): ?>
          <input type="radio" name="nota" id="n<?= $n ?>" value="<?= $n ?>" <?= (int) ($old['nota'] ?? 0) === $n ? 'checked' : '' ?> required>
          <label for="n<?= $n ?>" title="<?= $n ?> <?= $n === 1 ? 'estrela' : 'estrelas' ?>"><span class="sr"><?= $n ?> <?= $n === 1 ? 'estrela' : 'estrelas' ?></span>★</label>
        <?php endfor; ?>
      </div>
    </fieldset>
    <label class="campo">Seu nome
      <input name="nome" maxlength="60" required autocomplete="name" value="<?= h($old['nome'] ?? ($cliente['nome'] ?? '')) ?>">
    </label>
    <label class="campo">Comentário
      <textarea name="comentario" rows="4" maxlength="500" required><?= h($old['comentario'] ?? '') ?></textarea>
    </label>
    <div class="mel" aria-hidden="true"><label>Não preencha<input name="site" tabindex="-1" autocomplete="off"></label></div>
    <button class="btn" type="submit">Enviar avaliação</button>
    <p class="nota">O comentário só aparece no site depois de aprovado pela confeiteira.</p>
  </form>
</div></section>
