<?php
declare(strict_types=1);

/* Encerra a sessão do CLIENTE (não mexe no acesso do Kanban). */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos(true);
iniciar_sessao();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valido()) {
    unset($_SESSION['cliente_id']);
    session_regenerate_id(true);
}
redirecionar('index.php');
