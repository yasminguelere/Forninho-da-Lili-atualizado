<?php
declare(strict_types=1);

/* Cria a nova senha a partir do link recebido por e-mail (token de uso único). */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos(true);
header('Referrer-Policy: no-referrer');
iniciar_sessao();

$token = (string) ($_GET['token'] ?? $_POST['token'] ?? '');
$erro  = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha  = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
    $senha2 = is_string($_POST['senha2'] ?? null) ? $_POST['senha2'] : '';
    if (!csrf_valido()) {
        $erro = 'A página expirou. Tente de novo.';
    } elseif (($erro = problema_senha($senha)) !== null) {
        // mensagem já definida
    } elseif ($senha !== $senha2) {
        $erro = 'As senhas não são iguais.';
    } elseif (redefinir_senha($token, $senha)) {
        flash_set('ok', 'Senha alterada! Entre com a nova senha.', [], 'conta');
        redirecionar('login.php');
    } else {
        $erro = 'Este link expirou ou já foi usado. Peça um novo.';
        $token = '';
    }
}

$valido = token_reset_valido($token);
$titulo = 'Nova senha';
include __DIR__ . '/partials/auth-topo.php';
?>
  <?php if (!$valido): ?>
    <p class="msg msg-erro" role="alert"><?= h($erro ?? 'Este link expirou ou não é válido. Peça um novo.') ?></p>
    <p class="auth-links"><a href="esqueci-senha.php">Pedir novo link</a><a href="login.php">Entrar</a></p>
  <?php else: ?>
    <p class="nota">Escolha uma nova senha para a sua conta.</p>
    <?php if ($erro): ?><p class="msg msg-erro" role="alert"><?= h($erro) ?></p><?php endif; ?>
    <form method="post" action="redefinir-senha.php">
      <?= csrf_campo() ?>
      <input type="hidden" name="token" value="<?= h($token) ?>">
      <label class="campo">Nova senha
        <input type="password" name="senha" required autofocus autocomplete="new-password" minlength="<?= SENHA_MIN ?>" maxlength="200">
        <span class="dica">Mínimo de <?= SENHA_MIN ?> caracteres.</span>
      </label>
      <label class="campo">Repita a nova senha
        <input type="password" name="senha2" required autocomplete="new-password" minlength="<?= SENHA_MIN ?>" maxlength="200">
      </label>
      <button class="btn" type="submit">Salvar nova senha</button>
    </form>
  <?php endif; ?>
<?php include __DIR__ . '/partials/auth-rodape.php';
