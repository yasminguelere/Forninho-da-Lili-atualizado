<?php
declare(strict_types=1);

/* Site público: monta a página a partir dos módulos em partials/. */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos();

$cardapio  = require __DIR__ . '/../nucleo/cardapio.php';
$novidades = require __DIR__ . '/../nucleo/novidades.php';

// Só toca na sessão se o visitante já tem uma (mensagens e conta do cliente)
$temSessao = isset($_COOKIE[SESSAO_NOME]);
$flash   = $temSessao ? flash_get('publico') : null;
$cliente = $temSessao ? cliente_logado() : null;
$old     = is_array($flash['old'] ?? null) ? $flash['old'] : [];
iniciar_sessao(); // gera o token do formulário de avaliação

// Apenas avaliações aprovadas pela confeiteira aparecem no mural
$aprovadas = array_values(array_filter(ler_dados('avaliacoes'), fn ($a) => ($a['status'] ?? '') === 'destaque'));
$aprovadas = array_reverse($aprovadas); // desempate: o mais recente primeiro
usort($aprovadas, fn ($a, $b) => strcmp($b['criado_em'] ?? '', $a['criado_em'] ?? ''));

function slug(string $t): string
{
    $t = iconv('UTF-8', 'ASCII//TRANSLIT', $t) ?: $t;
    return trim(strtolower(preg_replace('/[^a-z0-9]+/i', '-', $t)), '-');
}

$fotos = [
    ['arq' => 'saquinho-biscoitos.jpg', 'alt' => 'Saquinho de biscoitos amanteigados com laço rosa e o selo do Forninho da Lili'],
    ['arq' => 'biscoitos-goiabada.jpg',  'alt' => 'Biscoitinhos de goiabada em uma bandeja de madeira em formato de coração, ao lado de uma xícara de café'],
    ['arq' => 'brigadeiros-aranha.jpg',  'alt' => 'Brigadeiros vermelhos decorados com teia de aranha dourada, edição especial'],
];
$msgGeral = 'Olá! Vim pelo site do ' . NOME_LOJA . ' e gostaria de fazer um pedido.';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#fff7f6">
<meta name="description" content="Forninho da Lili: confeitaria artesanal. Cookies, biscoitinhos, coxinhas e brigadeiros feitos à mão. Peça pelo WhatsApp.">
<link rel="icon" href="fotos/logo.png">
<title>Forninho da Lili · Confeitaria artesanal</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Dancing+Script:wght@600;700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/site.css">
<script src="js/tema.js"></script>
<script src="js/carrinho.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/partials/cabecalho.php'; ?>
<main>
<?php
include __DIR__ . '/partials/hero.php';
include __DIR__ . '/partials/como-funciona.php';
include __DIR__ . '/partials/cardapio.php';
include __DIR__ . '/partials/galeria.php';
include __DIR__ . '/partials/novidades.php';
include __DIR__ . '/partials/avaliacoes.php';
include __DIR__ . '/partials/sobre.php';
?>
</main>
<?php include __DIR__ . '/partials/rodape.php'; ?>
<?php include __DIR__ . '/partials/carrinho.php'; ?>
</body>
</html>
