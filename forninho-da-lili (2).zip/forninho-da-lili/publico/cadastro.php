<?php
declare(strict_types=1);

/* Criar conta de cliente. */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos(true);
iniciar_sessao();

if (cliente_logado()) {
    redirecionar(REDIRECT_POS_LOGIN_CLIENTE);
}

$erro = null;
$nome = $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome   = preg_replace('/\s+/u', ' ', limpar_texto($_POST['nome'] ?? '')) ?? '';
    $email  = normalizar_email($_POST['email'] ?? '');
    $senha  = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
    $senha2 = is_string($_POST['senha2'] ?? null) ? $_POST['senha2'] : '';

    if (!csrf_valido()) {
        $erro = 'A página expirou. Tente de novo.';
    } elseif (($espera = segundos_bloqueado('cad')) > 0) {
        $erro = 'Muitas tentativas. Aguarde ' . (int) ceil($espera / 60) . ' min.';
    } else {
        registrar_falha('cad');   // limita cadastros por visitante (5 a cada 10 min)
        if ($nome === '' || mb_strlen($nome) > 60) {
            $erro = 'Informe seu nome (até 60 letras).';
        } elseif (!email_valido($email)) {
            $erro = 'Informe um e-mail válido.';
        } elseif (($erro = problema_senha($senha)) !== null) {
            // mensagem já definida
        } elseif ($senha !== $senha2) {
            $erro = 'As senhas não são iguais.';
        } else {
            [$cliente, $erro] = criar_cliente($nome, $email, $senha);
            if ($cliente) {
                iniciar_sessao_cliente($cliente);
                redirecionar(REDIRECT_POS_LOGIN_CLIENTE);
            }
        }
    }
}

$titulo = 'Criar conta';
include __DIR__ . '/partials/auth-topo.php';
?>
  <p class="nota">Cadastro rápido. Não é necessário para fazer pedidos, que são feitos pelo WhatsApp.</p>
  <?php if ($erro): ?><p class="msg msg-erro" role="alert"><?= h($erro) ?></p><?php endif; ?>
  <form method="post" action="cadastro.php">
    <?= csrf_campo() ?>
    <label class="campo">Nome
      <input name="nome" required autofocus autocomplete="name" maxlength="60" value="<?= h($nome) ?>">
    </label>
    <label class="campo">E-mail
      <input type="email" name="email" required autocomplete="email" maxlength="120" value="<?= h($email) ?>">
    </label>
    <label class="campo">Senha
      <input type="password" name="senha" required autocomplete="new-password" minlength="<?= SENHA_MIN ?>" maxlength="200">
      <span class="dica">Mínimo de <?= SENHA_MIN ?> caracteres.</span>
    </label>
    <label class="campo">Repita a senha
      <input type="password" name="senha2" required autocomplete="new-password" minlength="<?= SENHA_MIN ?>" maxlength="200">
    </label>
    <button class="btn" type="submit">Criar conta</button>
  </form>
  <p class="auth-links"><a href="login.php">Já tenho conta</a><a href="index.php">Voltar ao site</a></p>
<?php include __DIR__ . '/partials/auth-rodape.php';
