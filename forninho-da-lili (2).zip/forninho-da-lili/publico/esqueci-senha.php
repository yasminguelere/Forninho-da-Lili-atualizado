<?php
declare(strict_types=1);

/* Pede o link de redefinição de senha. A resposta é igual exista ou não a conta. */

require __DIR__ . '/../nucleo/clientes.php';
cabecalhos(true);
iniciar_sessao();

$erro = null;
$enviado = false;
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = normalizar_email($_POST['email'] ?? '');
    if (!csrf_valido()) {
        $erro = 'A página expirou. Tente de novo.';
    } elseif (!email_valido($email)) {
        $erro = 'Informe um e-mail válido.';
    } elseif (($espera = segundos_bloqueado('rec')) > 0) {
        $erro = 'Muitas tentativas. Aguarde ' . (int) ceil($espera / 60) . ' min.';
    } else {
        registrar_falha('rec');
        pedir_recuperacao($email);
        $enviado = true;
    }
}

$titulo = 'Esqueci minha senha';
include __DIR__ . '/partials/auth-topo.php';
?>
  <?php if ($enviado): ?>
    <p class="msg msg-ok" role="status">Se existir uma conta com esse e-mail, enviamos um link para criar uma nova senha. Ele vale por 1 hora.</p>
  <?php else: ?>
    <p class="nota">Digite o e-mail da sua conta e enviaremos um link para criar uma nova senha.</p>
    <?php if ($erro): ?><p class="msg msg-erro" role="alert"><?= h($erro) ?></p><?php endif; ?>
    <form method="post" action="esqueci-senha.php">
      <?= csrf_campo() ?>
      <label class="campo">E-mail
        <input type="email" name="email" required autofocus autocomplete="email" maxlength="120" value="<?= h($email) ?>">
      </label>
      <button class="btn" type="submit">Enviar link</button>
    </form>
  <?php endif; ?>
  <p class="auth-links"><a href="login.php">Voltar para entrar</a><a href="cadastro.php">Criar conta</a></p>
<?php include __DIR__ . '/partials/auth-rodape.php';
