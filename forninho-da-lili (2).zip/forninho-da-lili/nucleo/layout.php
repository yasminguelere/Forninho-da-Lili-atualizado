<?php
declare(strict_types=1);

/* Peças de tela compartilhadas pelas páginas do Kanban (site privado). */

require_once __DIR__ . '/funcoes.php';

const COLUNAS = [
    'pendente' => 'Pendente',
    'producao' => 'Em Produção',
    'pronto'   => 'Pronto',
    'entregue' => 'Entregue',
];

const URGENCIAS = [
    'verde'    => 'Verde',
    'amarelo'  => 'Amarelo',
    'vermelho' => 'Vermelho',
];

const PAGAMENTOS = [
    'pendente' => 'Pendente',
    'pago'     => 'Pago',
];

/** Garante o formato atual de um pedido (aceita pedidos gravados na versão de 3 colunas). */
function normalizar_pedido(array $p): array
{
    $antigos = ['fazer' => 'pendente', 'concluido' => 'entregue'];
    $st = $antigos[$p['status'] ?? ''] ?? ($p['status'] ?? 'pendente');
    $p['status']    = isset(COLUNAS[$st]) ? $st : 'pendente';
    $p['pagamento'] = isset(PAGAMENTOS[$p['pagamento'] ?? '']) ? $p['pagamento'] : 'pendente';
    $p['hora']      = is_string($p['hora'] ?? null) ? $p['hora'] : '';
    return $p;
}

function kanban_topo(string $titulo, string $ativa = 'pedidos'): void
{
    $novos = count(array_filter(ler_dados('avaliacoes'), fn ($a) => ($a['status'] ?? 'novo') === 'novo'));
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<link rel="icon" href="../publico/fotos/logo.png">
<title><?= h($titulo) ?> · Gestão do Forninho</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/kanban.css">
<script src="../publico/js/tema.js"></script>
</head>
<body>
<header class="barra">
  <div class="barra-in">
    <a class="logo" href="painel.php"><span class="logo-sigla">FL</span><span>Gestão<small>Forninho da Lili</small></span></a>
    <nav class="menu" aria-label="Principal">
      <a href="painel.php"<?= $ativa === 'pedidos' ? ' aria-current="page"' : '' ?>>Pedidos</a>
      <a href="comentarios.php"<?= $ativa === 'comentarios' ? ' aria-current="page"' : '' ?>>Comentários<?php if ($novos > 0): ?> <span class="contador" title="<?= $novos ?> novo(s)"><?= $novos ?></span><?php endif; ?></a>
      <a href="<?= h(URL_PUBLICO) ?>" target="_blank" rel="noopener">Ver site</a>
    </nav>
    <span class="usuario" title="Sessão iniciada com a chave de acesso"><span class="usuario-ponto" aria-hidden="true"></span>Administradora</span>
    <?= botao_tema() ?>
    <form class="sair" method="post" action="sair.php"><?= csrf_campo() ?><button class="btn-link" type="submit">Sair</button></form>
  </div>
</header>
<main class="conteudo">
<?php
    exibir_flash();
}

function kanban_rodape(): void
{
    ?>
</main>
</body>
</html>
<?php
}

function exibir_flash(): void
{
    $f = flash_get('kanban');
    if ($f) {
        echo '<p class="aviso aviso-' . h($f['tipo']) . '" role="status">' . h($f['msg']) . '</p>';
    }
}

/** Grupo de botões de opção (urgência / pagamento). */
function opcoes_radio(string $nome, array $opcoes, string $atual, string $idBase, string $classe): void
{
    echo '<div class="urgencias">';
    foreach ($opcoes as $chave => $rotulo) {
        $id = $nome . '-' . $chave . '-' . $idBase;
        echo '<input type="radio" name="' . h($nome) . '" id="' . h($id) . '" value="' . h($chave) . '"' . ($atual === $chave ? ' checked' : '') . '>';
        echo '<label class="urg ' . $classe . '-' . h($chave) . '" for="' . h($id) . '">' . h($rotulo) . '</label>';
    }
    echo '</div>';
}

/** Formulário de pedido (usado para criar em painel.php e editar em editar.php). */
function form_pedido(array $v, string $acao, string $id = '', array $erros = []): void
{
    $v += ['cliente' => '', 'descricao' => '', 'valor' => '', 'entrega' => '', 'hora' => '', 'urgencia' => 'verde', 'pagamento' => 'pendente'];
    $base = $id ?: 'novo';
    ?>
<form class="form-pedido" method="post" action="acao.php">
  <?= csrf_campo() ?>
  <input type="hidden" name="acao" value="<?= h($acao) ?>">
  <?php if ($id !== ''): ?><input type="hidden" name="id" value="<?= h($id) ?>"><?php endif; ?>
  <?php if ($erros): ?>
    <ul class="erros" role="alert"><?php foreach ($erros as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
  <?php endif; ?>
  <div class="form-grade">
    <label class="campo c-cliente">Nome do cliente
      <input name="cliente" maxlength="80" required value="<?= h($v['cliente']) ?>" autocomplete="off">
    </label>
    <label class="campo c-valor">Valor (R$)
      <input name="valor" inputmode="decimal" required placeholder="0,00" maxlength="14" value="<?= h($v['valor']) ?>" autocomplete="off">
    </label>
    <label class="campo c-data">Data de entrega
      <input type="date" name="entrega" required value="<?= h($v['entrega']) ?>">
    </label>
    <label class="campo c-hora">Horário
      <input type="time" name="hora" value="<?= h($v['hora']) ?>">
    </label>
    <label class="campo c-desc">Itens encomendados
      <textarea name="descricao" rows="2" maxlength="300" required><?= h($v['descricao']) ?></textarea>
    </label>
    <fieldset class="campo c-urg">
      <legend>Nível de urgência</legend>
      <?php opcoes_radio('urgencia', URGENCIAS, (string) $v['urgencia'], $base, 'urg'); ?>
    </fieldset>
    <fieldset class="campo c-pag">
      <legend>Pagamento</legend>
      <?php opcoes_radio('pagamento', PAGAMENTOS, (string) $v['pagamento'], $base, 'pag'); ?>
    </fieldset>
  </div>
  <div class="form-botoes">
    <button class="btn" type="submit"><?= $acao === 'editar' ? 'Salvar alterações' : 'Adicionar pedido' ?></button>
    <?php if ($acao === 'editar'): ?><a class="btn btn-sec" href="painel.php">Cancelar</a><?php endif; ?>
  </div>
</form>
<?php
}

/** Valida os campos do formulário de pedido. Devolve [dados, erros, valoresParaReexibir]. */
function validar_pedido(array $in): array
{
    $erros = [];
    $cliente   = preg_replace('/\s+/u', ' ', limpar_texto($in['cliente'] ?? '')) ?? '';
    $descricao = limpar_texto($in['descricao'] ?? '');
    $valorTxt  = limpar_texto($in['valor'] ?? '');
    $entrega   = limpar_texto($in['entrega'] ?? '');
    $hora      = limpar_texto($in['hora'] ?? '');
    $urgencia  = is_string($in['urgencia'] ?? null) ? $in['urgencia'] : '';
    $pagamento = is_string($in['pagamento'] ?? null) ? $in['pagamento'] : '';

    if ($cliente === '' || mb_strlen($cliente) > 80) {
        $erros[] = 'Informe o nome do cliente (até 80 caracteres).';
    }
    if ($descricao === '' || mb_strlen($descricao) > 300) {
        $erros[] = 'Descreva os itens do pedido (até 300 caracteres).';
    }
    $centavos = parse_valor($valorTxt);
    if ($centavos === null) {
        $erros[] = 'Valor inválido. Use o formato 25,00 (maior que zero).';
    }
    $d = DateTime::createFromFormat('!Y-m-d', $entrega);
    if (!$d || $d->format('Y-m-d') !== $entrega) {
        $erros[] = 'Informe uma data de entrega válida.';
    }
    if ($hora !== '' && !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $hora)) {
        $erros[] = 'Horário inválido.';
    }
    if (!isset(URGENCIAS[$urgencia])) {
        $erros[] = 'Escolha o nível de urgência.';
    }
    if (!isset(PAGAMENTOS[$pagamento])) {
        $erros[] = 'Escolha a situação do pagamento.';
    }

    $dados = [
        'cliente'        => $cliente,
        'descricao'      => $descricao,
        'valor_centavos' => $centavos ?? 0,
        'entrega'        => $entrega,
        'hora'           => $hora,
        'urgencia'       => $urgencia,
        'pagamento'      => $pagamento,
    ];
    $antigos = [
        'cliente' => $cliente, 'descricao' => $descricao, 'valor' => $valorTxt, 'entrega' => $entrega, 'hora' => $hora,
        'urgencia' => isset(URGENCIAS[$urgencia]) ? $urgencia : 'verde',
        'pagamento' => isset(PAGAMENTOS[$pagamento]) ? $pagamento : 'pendente',
    ];
    return [$dados, $erros, $antigos];
}
