<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/* ---------------------------------------------------------------
 *  Utilidades de saída e cabeçalhos
 * ------------------------------------------------------------- */

function h(?string $texto): string
{
    return htmlspecialchars((string) $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Cabeçalhos de segurança. A CSP só aceita scripts do próprio site (nada de script inline). */
function cabecalhos(bool $privado = false): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    header("Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
        . "font-src https://fonts.gstatic.com; img-src 'self' data:; form-action 'self'; "
        . "base-uri 'none'; frame-ancestors 'none'");
    if ($privado) {
        header('Cache-Control: no-store');
        header('X-Robots-Tag: noindex, nofollow');
    }
}

function redirecionar(string $url, int $codigo = 303): never
{
    header('Location: ' . $url, true, $codigo);
    exit;
}

/* ---------------------------------------------------------------
 *  Sessão (compartilhada entre publico/ e kanban/)
 * ------------------------------------------------------------- */

function esta_em_https(): bool
{
    $https = $_SERVER['HTTPS'] ?? '';
    return ($https !== '' && strtolower($https) !== 'off')
        || strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}

function iniciar_sessao(): void
{
    if (session_status() !== PHP_SESSION_NONE) {
        return;
    }
    // O cookie vale para a pasta-mãe dos dois sites, assim o login de um vale para o outro.
    $pai = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/x/x.php')), '/\\') . '/';
    session_name(SESSAO_NOME);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => $pai,
        'secure'   => esta_em_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function sair_sessao(): void
{
    iniciar_sessao();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 3600, 'path' => $p['path'], 'secure' => $p['secure'],
            'httponly' => true, 'samesite' => 'Lax',
        ]);
    }
    session_destroy();
}

/** Barreira de proteção: chamada no topo de TODA página do Kanban. */
function exigir_login(): void
{
    iniciar_sessao();
    $vencida = (time() - (int) ($_SESSION['ultimo'] ?? 0)) > SESSAO_INATIVIDADE;
    if (empty($_SESSION['auth']) || $vencida) {
        sair_sessao();
        // Quem não está autenticado e abre uma URL protegida vai direto para a vitrine pública
        redirecionar(URL_PUBLICO . 'index.php', 302);
    }
    $_SESSION['ultimo'] = time();
}

function esta_logado(): bool
{
    iniciar_sessao();
    return !empty($_SESSION['auth'])
        && (time() - (int) ($_SESSION['ultimo'] ?? 0)) <= SESSAO_INATIVIDADE;
}

/* ---------------------------------------------------------------
 *  CSRF e mensagens rápidas (flash)
 * ------------------------------------------------------------- */

function csrf_token(): string
{
    iniciar_sessao();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function csrf_valido(): bool
{
    iniciar_sessao();
    $enviado = $_POST['csrf'] ?? '';
    return is_string($enviado) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $enviado);
}

/** Mensagens de uma só leitura. "canal" separa o site público do Kanban (a sessão é compartilhada). */
function flash_set(string $tipo, string $mensagem, array $extra = [], string $canal = 'kanban'): void
{
    iniciar_sessao();
    $_SESSION['flash_' . $canal] = ['tipo' => $tipo, 'msg' => $mensagem] + $extra;
}

function flash_get(string $canal = 'kanban'): ?array
{
    iniciar_sessao();
    $f = $_SESSION['flash_' . $canal] ?? null;
    unset($_SESSION['flash_' . $canal]);
    return is_array($f) ? $f : null;
}

/* ---------------------------------------------------------------
 *  Login por chave única (usado por publico/login.php e kanban/index.php)
 * ------------------------------------------------------------- */

function verificar_chave(string $tentativa): bool
{
    if ($tentativa === '' || strlen($tentativa) > 200) {
        return false;
    }
    if (str_starts_with(CHAVE_ACESSO, '$2y$')) {
        return password_verify($tentativa, CHAVE_ACESSO);
    }
    return hash_equals(CHAVE_ACESSO, $tentativa);
}

function ip_hash(string $ctx = ''): string
{
    return hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0') . '|forninho-da-lili' . ($ctx !== '' ? '|' . $ctx : ''));
}

function segundos_bloqueado(string $ctx = 'adm'): int
{
    $r = ler_dados('tentativas')[ip_hash($ctx)] ?? null;
    return ($r && ($r['ate'] ?? 0) > time()) ? (int) $r['ate'] - time() : 0;
}

function registrar_falha(string $ctx = 'adm'): void
{
    atualizar_dados('tentativas', function (array &$d) use ($ctx): void {
        $agora = time();
        foreach ($d as $k => $v) {
            if (($v['ultima'] ?? 0) < $agora - 3600) {
                unset($d[$k]);
            }
        }
        $k = ip_hash($ctx);
        $r = $d[$k] ?? ['n' => 0, 'ate' => 0, 'ultima' => 0];
        if ($r['ultima'] < $agora - BLOQUEIO_SEGUNDOS) {
            $r['n'] = 0;
        }
        $r['n']++;
        $r['ultima'] = $agora;
        if ($r['n'] >= MAX_TENTATIVAS) {
            $r['ate'] = $agora + BLOQUEIO_SEGUNDOS;
            $r['n'] = 0;
        }
        $d[$k] = $r;
    });
}

function limpar_falhas(string $ctx = 'adm'): void
{
    atualizar_dados('tentativas', function (array &$d) use ($ctx): void {
        unset($d[ip_hash($ctx)]);
    });
}

/** Valida o POST do formulário de chave. Devolve null se entrou, ou a mensagem de erro. */
function tentar_login(): ?string
{
    iniciar_sessao();
    if (!csrf_valido()) {
        return 'A página expirou. Tente de novo.';
    }
    $espera = segundos_bloqueado();
    if ($espera > 0) {
        return 'Muitas tentativas erradas. Aguarde ' . (int) ceil($espera / 60) . ' min e tente de novo.';
    }
    $chave = $_POST['chave'] ?? '';
    if (is_string($chave) && verificar_chave($chave)) {
        session_regenerate_id(true);
        $_SESSION['auth'] = true;
        $_SESSION['ultimo'] = time();
        unset($_SESSION['csrf']);
        limpar_falhas();
        return null;
    }
    registrar_falha();
    usleep(400000);
    return 'Chave incorreta.';
}

/* ---------------------------------------------------------------
 *  Armazenamento em arquivos (sem banco de dados)
 *  Cada arquivo começa com uma linha PHP que devolve 404 e encerra,
 *  então ele nunca pode ser baixado pelo navegador, mesmo sem .htaccess.
 * ------------------------------------------------------------- */

const CABECALHO_DADOS = "<?php http_response_code(404); exit; ?>\n";

function arquivo_dados(string $nome): string
{
    return DIR_DADOS . '/' . preg_replace('/[^a-z0-9_-]/i', '', $nome) . '.json.php';
}

function decodificar_dados(string $conteudo): array
{
    if (str_starts_with($conteudo, CABECALHO_DADOS)) {
        $conteudo = substr($conteudo, strlen(CABECALHO_DADOS));
    }
    $d = json_decode($conteudo, true);
    return is_array($d) ? $d : [];
}

function ler_dados(string $nome): array
{
    $f = arquivo_dados($nome);
    if (!is_file($f) || !($fp = fopen($f, 'rb'))) {
        return [];
    }
    flock($fp, LOCK_SH);
    $conteudo = (string) stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return decodificar_dados($conteudo);
}

/** Lê, deixa a função alterar (por referência) e grava, tudo travado contra gravações simultâneas. */
function atualizar_dados(string $nome, callable $alterar): mixed
{
    if (!is_dir(DIR_DADOS)) {
        mkdir(DIR_DADOS, 0750, true);
    }
    $fp = fopen(arquivo_dados($nome), 'c+b');
    if (!$fp) {
        throw new RuntimeException('Não foi possível abrir o arquivo de dados.');
    }
    try {
        flock($fp, LOCK_EX);
        $dados = decodificar_dados((string) stream_get_contents($fp));
        $retorno = $alterar($dados);
        $json = json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, CABECALHO_DADOS . $json);
        fflush($fp);
        return $retorno;
    } finally {
        flock($fp, LOCK_UN);
        fclose($fp);
    }
}

/* ---------------------------------------------------------------
 *  Texto, dinheiro e datas
 * ------------------------------------------------------------- */

function limpar_texto(mixed $valor): string
{
    $s = is_string($valor) ? $valor : '';
    $s = str_replace("\r\n", "\n", $s);
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s) ?? '';
    return trim($s);
}

/** "1.250,50", "12,5", "12.50" → centavos (int). Devolve null se inválido. */
function parse_valor(string $texto): ?int
{
    $s = str_replace(['R$', ' ', "\u{00A0}"], '', trim($texto));
    if (!preg_match('/^(\d{1,3}(\.\d{3})+(,\d{1,2})?|\d+(,\d{1,2})?|\d+\.\d{1,2})$/', $s)) {
        return null;
    }
    if (str_contains($s, ',')) {
        $s = str_replace(['.', ','], ['', '.'], $s);
    } elseif (preg_match('/^\d{1,3}(\.\d{3})+$/', $s)) {
        $s = str_replace('.', '', $s);
    }
    $centavos = (int) round(((float) $s) * 100);
    return ($centavos > 0 && $centavos <= 100000000) ? $centavos : null;
}

function reais(int $centavos): string
{
    return 'R$ ' . number_format($centavos / 100, 2, ',', '.');
}

function reais_float(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

function data_br(string $iso): string
{
    $d = DateTime::createFromFormat('!Y-m-d', substr($iso, 0, 10));
    return $d ? $d->format('d/m/Y') : '';
}

function data_hora_br(string $iso): string
{
    try {
        return (new DateTime($iso))->format('d/m/Y \à\s H:i');
    } catch (Throwable) {
        return '';
    }
}

function novo_id(): string
{
    return bin2hex(random_bytes(6));
}

function estrelas(int $nota): string
{
    $nota = max(0, min(5, $nota));
    return str_repeat('★', $nota) . str_repeat('☆', 5 - $nota);
}

function link_whatsapp(string $mensagem): string
{
    return 'https://wa.me/' . WHATSAPP_NUMERO . '?text=' . rawurlencode($mensagem);
}

/** Endereço base do site público, usado nos links enviados por e-mail. */
function url_base_publico(): string
{
    if (URL_BASE_SITE !== '') {
        return rtrim(URL_BASE_SITE, '/');
    }
    $host = preg_replace('/[^a-z0-9.\-:\[\]]/i', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    return (esta_em_https() ? 'https' : 'http') . '://' . $host . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
}

/** Botão de alternar tema claro/escuro (só aparece com JavaScript; ver js/tema.js). */
function botao_tema(): string
{
    return '<button class="btn-tema so-js" type="button" data-tema-toggle aria-pressed="false" aria-label="Mudar para tema escuro">'
        . '<svg class="ico-lua" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>'
        . '<svg class="ico-sol" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="4.5" fill="currentColor"/><g stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/></g></svg>'
        . '</button>';
}
