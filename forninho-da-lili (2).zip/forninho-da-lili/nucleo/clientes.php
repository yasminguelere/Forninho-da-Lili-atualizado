<?php
declare(strict_types=1);

/* Contas de clientes do site público: cadastro, login, recuperação de senha. */

require_once __DIR__ . '/funcoes.php';
require_once __DIR__ . '/email.php';

// Hash fictício: gasta o mesmo tempo quando o e-mail não existe (evita descobrir quem tem conta).
const HASH_FALSO = '$2y$10$lAK5mobjTZLcgBFms3ci3ujJZK.6OPTpel.tm3vIgDZ/ybKNEtf.C';

function normalizar_email(mixed $e): string
{
    return mb_strtolower(trim(is_string($e) ? $e : ''));
}

function email_valido(string $e): bool
{
    return $e !== '' && strlen($e) <= 120 && filter_var($e, FILTER_VALIDATE_EMAIL) !== false;
}

/** Devolve a mensagem de problema da senha, ou null se estiver boa. */
function problema_senha(string $s): ?string
{
    if (mb_strlen($s) < SENHA_MIN) {
        return 'A senha precisa ter pelo menos ' . SENHA_MIN . ' caracteres.';
    }
    return strlen($s) > 200 ? 'A senha está muito longa.' : null;
}

function achar_cliente(string $email): ?array
{
    foreach (ler_dados('clientes') as $c) {
        if (($c['email'] ?? '') === $email) {
            return $c;
        }
    }
    return null;
}

function cliente_logado(): ?array
{
    iniciar_sessao();
    $id = $_SESSION['cliente_id'] ?? null;
    if (!is_string($id)) {
        return null;
    }
    foreach (ler_dados('clientes') as $c) {
        if (($c['id'] ?? '') === $id) {
            return $c;
        }
    }
    unset($_SESSION['cliente_id']);
    return null;
}

/** Protege páginas da área do cliente. */
function exigir_cliente(): array
{
    $c = cliente_logado();
    if (!$c) {
        redirecionar('login.php');
    }
    return $c;
}

function iniciar_sessao_cliente(array $c): void
{
    session_regenerate_id(true);
    $_SESSION['cliente_id'] = $c['id'];
    unset($_SESSION['csrf']);
}

/** POST de login do cliente. Devolve null se entrou, ou a mensagem de erro. */
function tentar_login_cliente(string $email, string $senha): ?string
{
    if (!csrf_valido()) {
        return 'A página expirou. Tente de novo.';
    }
    if (($espera = segundos_bloqueado('cli')) > 0) {
        return 'Muitas tentativas. Aguarde ' . (int) ceil($espera / 60) . ' min e tente de novo.';
    }
    $c  = achar_cliente($email);
    $ok = password_verify($senha, $c['senha_hash'] ?? HASH_FALSO) && $c !== null && strlen($senha) <= 200;
    if (!$ok) {
        registrar_falha('cli');
        return 'E-mail ou senha incorretos.';
    }
    limpar_falhas('cli');
    iniciar_sessao_cliente($c);
    return null;
}

/** Cria a conta. Devolve [cliente|null, erro|null]. */
function criar_cliente(string $nome, string $email, string $senha): array
{
    $novo = null;
    $erro = atualizar_dados('clientes', function (array &$lista) use ($nome, $email, $senha, &$novo): ?string {
        foreach ($lista as $c) {
            if (($c['email'] ?? '') === $email) {
                return 'Este e-mail já tem cadastro. Tente entrar.';
            }
        }
        $novo = [
            'id' => novo_id(), 'nome' => $nome, 'email' => $email,
            'senha_hash' => password_hash($senha, PASSWORD_DEFAULT), 'criado_em' => date('c'),
        ];
        $lista[] = $novo;
        return null;
    });
    return [$erro === null ? $novo : null, $erro];
}

/* ---- Recuperação de senha ------------------------------------------------ */

function pedir_recuperacao(string $email): void
{
    $c = achar_cliente($email);
    if (!$c) {
        return;   // resposta é sempre a mesma, exista ou não a conta
    }
    $token = bin2hex(random_bytes(32));
    $hash  = hash('sha256', $token);
    atualizar_dados('reset', function (array &$l) use ($c, $hash): void {
        $agora = time();
        $l = array_values(array_filter($l, fn ($r) => $r['exp'] > $agora && $r['cid'] !== $c['id']));
        $l[] = ['h' => $hash, 'cid' => $c['id'], 'exp' => $agora + RESET_VALIDADE];
    });
    $link = url_base_publico() . '/redefinir-senha.php?token=' . $token;
    enviar_email($c['email'], 'Redefinir sua senha · ' . NOME_LOJA,
        "Olá, {$c['nome']}!\n\nPara criar uma nova senha, abra o link abaixo (vale por 1 hora):\n\n{$link}\n\n"
        . "Se não foi você, ignore esta mensagem.\n\n{$c['nome']}, com carinho,\n" . NOME_LOJA);
}

function token_reset_valido(string $token): bool
{
    if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
        return false;
    }
    $h = hash('sha256', $token);
    foreach (ler_dados('reset') as $r) {
        if (hash_equals($r['h'], $h) && $r['exp'] > time()) {
            return true;
        }
    }
    return false;
}

function redefinir_senha(string $token, string $nova): bool
{
    if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
        return false;
    }
    $h = hash('sha256', $token);
    $cid = atualizar_dados('reset', function (array &$l) use ($h): ?string {
        foreach ($l as $i => $r) {
            if (hash_equals($r['h'], $h)) {
                unset($l[$i]);
                $l = array_values($l);
                return $r['exp'] > time() ? $r['cid'] : null;
            }
        }
        return null;
    });
    if ($cid === null) {
        return false;
    }
    atualizar_dados('clientes', function (array &$l) use ($cid, $nova): void {
        foreach ($l as &$c) {
            if ($c['id'] === $cid) {
                $c['senha_hash'] = password_hash($nova, PASSWORD_DEFAULT);
            }
        }
    });
    return true;
}
