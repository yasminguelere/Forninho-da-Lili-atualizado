<?php
declare(strict_types=1);

/*
 * CARDÁPIO DO SITE PÚBLICO — edite aqui.
 *
 * Cada categoria tem uma lista de produtos. Campos de cada produto:
 *   nome, preco (em reais), descricao
 *   foto  (opcional) → nome do arquivo dentro de publico/fotos/ ; deixe null se não houver foto
 *   alt   (opcional) → descrição da foto para leitores de tela
 *   tamanho, ingredientes (opcionais) → texto exibido em "Detalhes"
 *
 * Produtos sem foto aparecem normalmente, só sem a imagem.
 */

return [
    'Cookies' => [
        [
            'nome' => 'Cookies',
            'preco' => 15.00,
            'descricao' => 'Sabores: Brigadeiro Tradicional, Brigadeiro de Ninho, Nutella e Doce de Leite.',
            'foto' => null,
        ],
    ],
    'Biscoitinhos' => [
        [
            'nome' => 'Biscoitinhos · Saquinho pequeno',
            'tamanho' => 'Saquinho pequeno',
            'preco' => 14.00,
            'descricao' => 'Biscoitinhos artesanais em saquinho com laço.',
            'foto' => 'saquinho-biscoitos.jpg',
            'alt' => 'Saquinho de biscoitos amanteigados com laço rosa e o selo do Forninho da Lili',
        ],
        [
            'nome' => 'Biscoitinhos · Meio quilo (500 g)',
            'tamanho' => 'Meio quilo (500 g)',
            'preco' => 25.00,
            'descricao' => 'Biscoitinhos artesanais.',
            'foto' => null,
        ],
        [
            'nome' => 'Biscoitinhos · 1 quilo (1 kg)',
            'tamanho' => '1 quilo (1 kg)',
            'preco' => 50.00,
            'descricao' => 'Biscoitinhos artesanais.',
            'foto' => null,
        ],
    ],
    'Coxinhas' => [
        [
            'nome' => 'Coxinhas',
            'preco' => 15.00,
            'descricao' => 'Coxinhas artesanais.',
            'foto' => null,
        ],
    ],
    'Brigadeiros' => [
        [
            'nome' => 'Brigadeiros · Caixinha com 4 unidades',
            'tamanho' => 'Caixinha com 4 unidades',
            'preco' => 16.00,
            'descricao' => 'Caixinha com 4 brigadeiros.',
            'foto' => null,
        ],
    ],
];
