<?php
declare(strict_types=1);

/*
 * NOVIDADES E PRÓXIMAS MUDANÇAS — aparecem na seção "Novidades" do site público.
 * Edite, apague ou adicione blocos. Campos: etiqueta, titulo, texto.
 *
 * ATENÇÃO: os textos abaixo são EXEMPLOS genéricos. Troque pelas novidades reais.
 */

return [
    [
        'etiqueta' => 'Em breve',
        'titulo'   => 'O Forninho está crescendo',
        'texto'    => 'Estamos nos preparando para uma nova fase, com mais espaço de produção e mais opções no cardápio. '
                    . 'Acompanhe por aqui: assim que tivermos detalhes, eles aparecem nesta página.',
    ],
    [
        'etiqueta' => 'Em teste',
        'titulo'   => 'Novos sabores a caminho',
        'texto'    => 'Estamos testando novas receitas. As que passarem no teste de sabor entram no cardápio.',
    ],
];
