<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

/**
 * Envia e-mail de texto simples (usa mail() do servidor).
 * Se o servidor não enviar (comum em testes locais), a mensagem fica registrada em
 * dados/emails.json.php para a dona consultar por FTP. Para produção, troque o corpo
 * desta função por PHPMailer/SMTP ou pelo serviço de e-mail que preferir.
 */
function enviar_email(string $para, string $assunto, string $texto): bool
{
    if (!filter_var($para, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $cabecalhos = 'From: ' . NOME_LOJA . ' <' . EMAIL_REMETENTE . ">\r\n"
        . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    $enviado = @mail($para, '=?UTF-8?B?' . base64_encode($assunto) . '?=', $texto, $cabecalhos);
    if (!$enviado) {
        atualizar_dados('emails', function (array &$l) use ($para, $assunto, $texto): void {
            $l[] = ['em' => date('c'), 'para' => $para, 'assunto' => $assunto, 'texto' => $texto];
            $l = array_slice($l, -50);
        });
    }
    return $enviado;
}
