<?php
declare(strict_types=1);

/*
 * =====================================================================
 *  CONFIGURAÇÃO GERAL — Forninho da Lili
 *  Este arquivo é usado pelos DOIS sites (publico/ e kanban/).
 * =====================================================================
 */

/*
 * CHAVE DE ACESSO ÚNICA (senha mestra) — troque antes de publicar!
 * Quem tiver esta chave entra no Kanban, tanto por publico/login.php
 * quanto por kanban/index.php.
 *
 * A chave fica guardada como HASH (bcrypt) e é conferida com password_verify().
 * Para trocar: php -r "echo password_hash('SUA-NOVA-CHAVE', PASSWORD_DEFAULT);"
 * e cole o resultado abaixo. (Texto puro também funciona, mas hash é mais seguro.)
 */
const CHAVE_ACESSO = '$2y$10$i4jPL0ffNLaUdYX3I4PK.uAP9BI0S1KwkzPopJtid4xlOYp/C9R9a';

/* Atendimento */
const NOME_LOJA        = 'Forninho da Lili';
const WHATSAPP_NUMERO  = '5511989634843';        // 55 + DDD + número, só dígitos
const WHATSAPP_EXIBIR  = '(11) 9.8963-4843';
const HORARIO          = 'Das 10h às 22h';
const AVISO_ALERGENOS = 'Produzido em cozinha que também manipula glúten, leite, ovos e nozes. '
    . 'Em caso de alergia, fale com a confeiteira antes de pedir.';


/* Carrinho: entrega. Com ENTREGA_ATIVA = false só existe retirada (sem custo).
   Com true, o carrinho oferece "Entrega" cobrando ENTREGA_TAXA e os avisos do site mudam. */
const ENTREGA_ATIVA = false;
const ENTREGA_TAXA  = 8.00;

/* Caminhos relativos entre os dois sites */
const URL_KANBAN  = '../kanban/';
const URL_PUBLICO = '../publico/';

/* Contas de clientes (site público) */
const REDIRECT_POS_LOGIN_CLIENTE = 'minha-conta.php';   // para onde o cliente vai depois de entrar (ex.: 'index.php')
const SENHA_MIN       = 8;
const RESET_VALIDADE  = 3600;                           // link de "esqueci minha senha" vale 1 h
const EMAIL_REMETENTE = 'nao-responda@forninhodalili.com.br';
const URL_BASE_SITE   = '';  // ex.: 'https://seudominio.com.br/publico'. Vazio = detectar automaticamente

/* Segurança */
const SESSAO_NOME         = 'forninho_sid';
const SESSAO_INATIVIDADE  = 14400;   // 4 h sem usar o painel = pede a chave de novo
const MAX_TENTATIVAS      = 5;       // erros de chave seguidos...
const BLOQUEIO_SEGUNDOS   = 600;     // ...e o acesso fica bloqueado por 10 min
const AVALIACOES_POR_HORA = 3;       // limite por visitante no formulário público

/* Pasta onde os dados (pedidos, avaliações) são gravados */
const DIR_DADOS = __DIR__ . '/../dados';

date_default_timezone_set('America/Sao_Paulo');
mb_internal_encoding('UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', '0');   // em produção não mostra erros na tela
ini_set('log_errors', '1');
