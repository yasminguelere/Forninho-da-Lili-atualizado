<?php
// Raiz do projeto: leva o visitante ao site público.
header('Location: publico/', true, 302);
exit;
